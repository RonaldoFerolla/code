﻿using System.ComponentModel.DataAnnotations;

namespace TGS.ValeGas.Infra.DTOs.Fornecedor
{
    public class FornecedorCadastroDto
    {
        [Required]
        [RegularExpression("([0-9]+)", ErrorMessage = "Apenas números deve ser informado")]
        public string CNPJ { get; set; }
        public string CamposExtras { get; set; }
        public string NomeFornecedor { get; set; }
    }
}
