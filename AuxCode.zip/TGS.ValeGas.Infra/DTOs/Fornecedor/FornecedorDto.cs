﻿using System.ComponentModel.DataAnnotations;

namespace TGS.ValeGas.Infra.DTOs.Fornecedor
{
    public class FornecedorDto
    {
        [Required]
        public string CNPJ { get; set; }
        public string CamposExtras { get; set; }
        public string NomeFornecedor { get; set; }
    }
}
