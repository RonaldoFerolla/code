﻿using System;
using System.ComponentModel.DataAnnotations;

namespace TGS.ValeGas.Infra.DTOs.Beneficiario
{
    public class BeneficiarioDto
    {
        [Key]
        public long Id { get; set; }
        [Required]
        public string NIS { get; set; }
        [Required]
        public string Nome { get; set; }
        [Required]
        public string CPF { get; set; }
        [Required]
        public DateTime DataNascimento { get; set; }
    }
}
