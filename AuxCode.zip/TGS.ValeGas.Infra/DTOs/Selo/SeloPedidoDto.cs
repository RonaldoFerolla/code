﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TGS.ValeGas.Infra.DTOs.Selo
{
    public class SeloPedidoDto
    {
        public string CNPJ { get; set; }
        public long Pagamento { get; set; }
        public long Quantidade { get; set; }

    }
}
