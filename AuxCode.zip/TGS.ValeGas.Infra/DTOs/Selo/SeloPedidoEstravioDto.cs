﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TGS.ValeGas.Infra.DTOs.Selo
{
    public class SeloPedidoEstravioDto
    {
    }
}
