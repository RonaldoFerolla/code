﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TGS.ValeGas.Infra.DTOs.SIMP
{
    public class CadastrarPedidoDto
    {
        public long NumeroPedido { get; set; }
        public int CodProduto { get; set; }
        public long NumeroPedidoCliente { get; set; }

    }
}
