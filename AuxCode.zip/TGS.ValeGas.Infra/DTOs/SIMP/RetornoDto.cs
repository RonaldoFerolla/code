﻿using Newtonsoft.Json;

namespace TGS.ValeGas.Infra.DTOs.SIMP
{
    public class RetornoDto
    {
        [JsonProperty("CodigoCliente")]
        public long CodigoCliente { get; set; }

        [JsonProperty("CodigoProduto")]
        public int CodigoProduto { get; set; }

        [JsonProperty("CodigoRemessaEntrada")]
        public int CodigoRemessaEntrada { get; set; }

        [JsonProperty("NumeroProcesso")]
        public long NumeroProcesso { get; set; }

        [JsonProperty("Observacao")]
        public string Observacao { get; set; }
    }
}
