﻿using System;

namespace TGS.ValeGas.Infra.DTOs.SIMP
{
    public class CadastrarSolicitanteDto
    {
        public long CodCliente { get; set; }

        public long CodSolicitante { get; set; }

        public string NomeRazao { get; set; }

        public string Email { get; set; }

        public bool FlagAtivo { get; set; }

    }
}
