﻿namespace TGS.ValeGas.Infra.DTOs.SIMP
{
    public class RequestDto
    {
        /// <summary>
        /// Código de cadastro do cliente dentro do SIMP
        /// Ex. (CNPJ)
        /// </summary>
        public long CodigoCliente { get; set; }

        /// <summary>
        /// Código de cadastro do produto dentro do SIMP
        /// </summary>
        public int CodigoProduto { get; set; }

        /// <summary>
        /// Código da operação de chamada
        /// </summary>
        public int CodigoOperacao { get; set; }

        /// <summary>
        /// Conteudo da chamada
        /// </summary>
        public object Content { get; set; }
    }
}
