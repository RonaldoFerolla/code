﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TGS.ValeGas.Infra.DTOs
{
    public class EnderecoDto
    {
        public string Endereco { get; set; }
        public int Numero { get; set; }
        public string Bairro { get; set; }
        public string Cidade { get; set; }
        public string CEP { get; set; }
        public string UF { get; set; }
        public bool EnderecoEntrega { get; set; }
        public string Complemento { get; set; }

    }
}
