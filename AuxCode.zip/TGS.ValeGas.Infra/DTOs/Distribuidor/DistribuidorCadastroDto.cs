﻿using System.ComponentModel.DataAnnotations;

namespace TGS.ValeGas.Infra.DTOs.Distribuidor
{
    public class DistribuidorCadastroDto
    {
        [Required]
        [RegularExpression("([0-9]+)", ErrorMessage ="Apenas números deve ser informado")]
        public string CNPJ { get; set; }
        
        [Required]
        public string NomeDistribuidor { get; set; }
        public string Email { get; set; }
        public EnderecoDto endereco { get; set; }

    }
}
