﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace TGS.ValeGas.Infra.DTOs.Distribuidor
{
    public class DistribuidorDto
    {
        [Required]
        public string CNPJ { get; set; }
        public string NomeDistribuidor { get; set; }
        public string CamposExtras { get; set; }
        public string Email { get; set; }
    }
}
