﻿using Refit;
using System.Net.Http;
using System.Threading.Tasks;
using TGS.ValeGas.Infra.DTOs.SIMP;

namespace TGS.ValeGas.Infra.Interfaces
{
    public interface IClientSimpApi
    {
        [Headers("Content-Type: application/json")]
        [Post("/api/IntegracaoCliente/ReceberDados")]
        Task<HttpContent> ReceberDados([Body] RequestDto request);
    }
}
