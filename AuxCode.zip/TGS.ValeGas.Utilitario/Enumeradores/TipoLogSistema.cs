﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TGS.ValeGas.Utilitario.Enumeradores
{
    public enum TipoLogSistema
    {
        BeneficiarioConsultarTodosException,
        BeneficiarioConsultarPorCNPJException,
        BeneficiarioConsultarPorNISException,
        BeneficiarioConsultarPorCPFException,
        BeneficiarioConsultarPorIDException,
        BeneficiarioCadastrarDadosException,
        BeneficiarioAlterarDadosException,
        BeneficiarioDeletarDadosException,

        DistribuidorConsultarTodosException,
        DistribuidorConsultarPorCNPJException,
        DistribuidorConsultarPorIdException,
        DistribuidorConsultarNISException,
        DistribuidorConsultarPorCPFException,
        DistribuidorConsultarPorIDException,
        DistribuidorAlterarDadosCPFException,
        DistribuidorCadastrarDadosCPFException,
        DistribuidorCadastrarDadosException,
        DistribuidorExcluirDadosCPFException,
        SeloConsultarException,
        SeloCadastrarPedidoException,

        FornecedorConsultarTodosException,
        FornecedorConsultarPorCNPJException,
        FornecedorConsultarPorIdException,
        FornecedorConsultarPorCPFException,
        FornecedorConsultarPorIDException,
        FornecedorAlterarDadosCPFException,
        FornecedorCadastrarDadosCPFException,
        FornecedorCadastrarDadosException,
        FornecedorExcluirDadosCPFException

    }

    
}

