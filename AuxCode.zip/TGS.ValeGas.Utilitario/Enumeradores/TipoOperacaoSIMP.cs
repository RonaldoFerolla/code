﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TGS.ValeGas.Utilitario.Enumeradores
{
    public enum TipoOperacaoSIMP
    {
        CadastrarPedido = 1,
        CadastrarSolicitante = 2,
        RegistraNF = 3,
        RegistraRecebimentoSeloRevendedor = 4,
    }
}
