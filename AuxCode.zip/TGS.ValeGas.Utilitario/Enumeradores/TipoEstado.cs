﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TGS.ValeGas.Utilitario.Enumeradores
{
    public enum TipoEstado
    {
        IdEstadoDistribuidorCadastro = 10,
        IdEstadoFornecedorCadastro = 10
    }

}
