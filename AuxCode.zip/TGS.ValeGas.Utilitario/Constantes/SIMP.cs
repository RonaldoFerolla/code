﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TGS.ValeGas.Utilitario.Constantes
{
    public class SIMP
    {
        public const long COD_CLIENTE = 12345678990;
        public const int KIT_PRODUTO = 999;
        public const int COD_PRODUTO = 1;
    }
}
