﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TGS.ValeGas.Domain.Entidades;
using TGS.ValeGas.Infra.DTOs.Fornecedor;

namespace TGS.ValeGas.Service.Interfaces
{
    public interface IFornecedorService
    {
        Task<IEnumerable<FornecedoresSelos>> ConsultaTodos();
        Task<FornecedoresSelos> ConsultarPorCNPJ(string cnpj);
        Task<FornecedoresSelos> ConsultarPorId(int id);
        Task<bool> AlterarDados(FornecedorDto distribuidores);
        Task<bool> DeletarDados(string cnpj);
        Task<Tuple<bool, string>> CadastrarDados(FornecedorCadastroDto Fornecedores);
    }
}
