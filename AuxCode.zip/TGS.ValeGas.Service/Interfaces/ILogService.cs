﻿using System.Threading.Tasks;
using TGS.ValeGas.Utilitario.Enumeradores;

namespace TGS.ValeGas.Service.Interfaces
{
    public interface ILogService
    {
        Task GravarLog(TipoLogSistema tipoLog, params object[] args);
    }
}
