﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TGS.ValeGas.Domain.Entidades;
using TGS.ValeGas.Infra.DTOs.Distribuidor;

namespace TGS.ValeGas.Service.Interfaces
{
    public interface IDistribuidorService
    {
        Task<IEnumerable<Distribuidores>> ConsultaTodos();
        Task<Distribuidores> ConsultarPorCNPJ(string cnpj);
        Task<Distribuidores> ConsultarPorId(int id);
        Task<bool> AlterarDados(DistribuidorDto distribuidores);
        Task<bool> DeletarDados(string cnpj);
        Task<Tuple<bool, string>> CadastrarDados(DistribuidorCadastroDto distribuidores);
    }
}
