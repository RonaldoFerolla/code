﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TGS.ValeGas.Domain.Entidades;
using TGS.ValeGas.Infra.DTOs.Beneficiario;

namespace TGS.ValeGas.Service.Interfaces
{
    public interface IBeneficiarioService
    {
        Task<IEnumerable<Beneficiarios>> ConsultaTodos();
        Task<Beneficiarios> ConsultarPorNIS(string nis);
        Task<Beneficiarios> ConsultarPorCPF(string cpf);
        Task<Beneficiarios> ConsultarPorID(long Id);
        Task<bool>CadastrarDados(BeneficiarioCadastrarDto beneficiarios);
        Task<bool> AlterarDados(BeneficiarioCadastrarDto beneficiarios);
        Task<bool> DeletarDados(BeneficiarioCadastrarDto beneficiarios);

    }
}
