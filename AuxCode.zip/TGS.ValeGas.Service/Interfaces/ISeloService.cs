﻿using System.Threading.Tasks;
using TGS.ValeGas.Domain.Entidades;
using TGS.ValeGas.Infra.DTOs.Selo;

namespace TGS.ValeGas.Service.Interfaces
{
    public interface ISeloService
    {
        Task<NumeracaoSelos> Consultar(string selo);

        Task<long> CadastrarPedido(SeloPedidoDto seloPedido);
    }
}
