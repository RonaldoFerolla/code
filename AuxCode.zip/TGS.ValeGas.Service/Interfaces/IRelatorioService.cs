﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TGS.ValeGas.Service.Interfaces
{
    public interface IRelatorioService
    {
    }
}
