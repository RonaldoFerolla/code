﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using TGS.ValeGas.Domain.Entidades;
using TGS.ValeGas.Infra.DTOs;
using TGS.ValeGas.Infra.DTOs.Distribuidor;
using TGS.ValeGas.Infra.DTOs.SIMP;
using TGS.ValeGas.Infra.Interfaces;
using TGS.ValeGas.Repository.Interfaces;
using TGS.ValeGas.Service.Interfaces;
using TGS.ValeGas.Utilitario.Constantes;
using TGS.ValeGas.Utilitario.Enumeradores;
using TGS.ValeGas.Utilitario.Helper;

namespace TGS.ValeGas.Service.Entidades
{
    public class DistribuidorService : IDistribuidorService
    {
        private readonly IDistribuidorRepository _distribuidorRepository;
        private readonly ILogService _logService;
        private readonly IClientSimpApi _clientSimpApi;
        private readonly IHttpClientFactory _clientFactory;

        public DistribuidorService(IDistribuidorRepository distribuidorRepository, ILogService logService, IClientSimpApi clientSimpApi, IHttpClientFactory clientFactory)
        {
            _distribuidorRepository = distribuidorRepository;
            _logService = logService;
            _clientSimpApi = clientSimpApi;
            _clientFactory = clientFactory;
        }

        public async Task<Tuple<bool, string>> CadastrarDados(DistribuidorCadastroDto distribuidores)
        {
            try
            {
                if (ValidaCNPJ.IsCnpj(distribuidores.CNPJ))
                {
                    var retorno_distribuidor = await _distribuidorRepository.ConsultarPorCNPJ(distribuidores.CNPJ);

                    if (retorno_distribuidor == null)
                    {
                        var entidade = new Distribuidores();
                        entidade.NuDocumento = long.Parse(distribuidores.CNPJ);
                        entidade.NomeDistribuidor = distribuidores.NomeDistribuidor;
                        entidade.CamposExtras = JsonConvert.SerializeObject(distribuidores.endereco);
                        entidade.IdEstadoDistribuidor = (int)TipoEstado.IdEstadoDistribuidorCadastro;
                        entidade.DataOperacao = DateTime.Now;

                        var resultado = await _distribuidorRepository.Cadastrar(entidade);

                        if (resultado == false)
                            throw new Exception("CNPJ já cadastrado");

                        //Popula Solicitante SIMP 
                        var solicitante = new CadastrarSolicitanteDto()
                        {
                            CodCliente = SIMP.COD_CLIENTE,
                            CodSolicitante = long.Parse(distribuidores.CNPJ),
                            NomeRazao = distribuidores.NomeDistribuidor,
                            Email = distribuidores.Email,
                            FlagAtivo = true
                        };

                        var obj = new RequestDto()
                        {
                            CodigoCliente = SIMP.COD_CLIENTE,
                            CodigoProduto = SIMP.KIT_PRODUTO,
                            CodigoOperacao = (int)TipoOperacaoSIMP.CadastrarSolicitante,
                            Content = JsonConvert.SerializeObject(new
                            {
                                Solicitante = solicitante,
                                Endereco = distribuidores.endereco
                            })
                        };



                        var client = _clientFactory.CreateClient("SimpApi");
                        var json = JsonConvert.SerializeObject(obj);
                        var httpContent = new StringContent(json, Encoding.UTF8, "application/json");
                        HttpResponseMessage response = await client.PostAsync("api/IntegracaoCliente/ReceberDados", httpContent);
                        var responseBody = await response.Content.ReadAsStringAsync();

                        if (!response.IsSuccessStatusCode)
                            throw new Exception(responseBody);

                        return new Tuple<bool, string>(true, "Cadastro Realizado com sucesso.");
                    }
                    else
                    {
                        await _logService.GravarLog(TipoLogSistema.DistribuidorCadastrarDadosException, distribuidores, "CadastrarDados - CNPJ já cadastrado");
                        return new Tuple<bool, string>(false, "CNPJ já cadastrado");
                    }
                }
                else
                {
                    await _logService.GravarLog(TipoLogSistema.DistribuidorCadastrarDadosException, distribuidores, "CadastrarDados - CNPJ invalido do distribuior");
                    return new Tuple<bool, string>(false, "CNPJ inválido");
                }
            }
            catch (Exception ex)
            {
                await _logService.GravarLog(TipoLogSistema.DistribuidorCadastrarDadosException, distribuidores, ex.Message);
            }

            return new Tuple<bool, string>(false, "Falha interna, entrar em contato com o administrador");
        }

        public async Task<bool> AlterarDados(DistribuidorDto distribuidores)
        {
            bool result = false;

            try
            {
                if (ValidaCNPJ.IsCnpj(distribuidores.CNPJ))
                {
                    var entidade = await _distribuidorRepository.ConsultarPorCNPJ(distribuidores.CNPJ);

                    if (entidade != null)
                    {
                        entidade.NomeDistribuidor = distribuidores.NomeDistribuidor;
                        entidade.CamposExtras = distribuidores.CamposExtras;
                        entidade.DataOperacao = DateTime.Now;

                        await _distribuidorRepository.Alterar(entidade);
                        result = true;
                    }
                    else
                    {
                        await _logService.GravarLog(TipoLogSistema.DistribuidorAlterarDadosCPFException, distribuidores, "AlterarDados - Retornou nulo ao consultar o CNPJ do Distrbuidor");
                    }
                }
                else
                {
                    await _logService.GravarLog(TipoLogSistema.DistribuidorAlterarDadosCPFException, distribuidores, "AlterarDados - CNPJ invalido do distribuior");
                }
            }
            catch (Exception ex)
            {
                await _logService.GravarLog(TipoLogSistema.DistribuidorAlterarDadosCPFException, distribuidores, ex.Message);
            }

            return result;
        }

        public async Task<bool> DeletarDados(string cnpj)
        {
            bool result = false;

            try
            {
                if (ValidaCNPJ.IsCnpj(cnpj))
                {
                    var entidade = await _distribuidorRepository.ConsultarPorCNPJ(cnpj);

                    if (entidade != null)
                    {
                        await _distribuidorRepository.Excluir(cnpj);
                        result = true;
                    }
                    else
                    {
                        await _logService.GravarLog(TipoLogSistema.DistribuidorExcluirDadosCPFException, cnpj, "DeletarDados - Retornou nulo ao consultar o CNPJ do Distrbuidor");
                    }
                }
                else
                {
                    await _logService.GravarLog(TipoLogSistema.DistribuidorExcluirDadosCPFException, cnpj, "DeletarDados - CNPJ invalido do distribuior");
                }
            }
            catch (Exception ex)
            {
                await _logService.GravarLog(TipoLogSistema.DistribuidorExcluirDadosCPFException, cnpj, ex.Message);
            }

            return result;
        }

        public async Task<Distribuidores> ConsultarPorCNPJ(string cnpj)
        {
            try
            {
                //var a = await _distribuidorRepository.ConsultarPorCNPJ(cnpj);
                //var b = await _distribuidorRepository.ConsultarPorCNPJEstado(cnpj);

                return await _distribuidorRepository.ConsultarPorCNPJ(cnpj);
            }
            catch (Exception ex)
            {
                await _logService.GravarLog(TipoLogSistema.DistribuidorConsultarPorCNPJException, cnpj, ex.Message);
            }
            return null;
        }

        public async Task<Distribuidores> ConsultarPorId(int id)
        {
            try
            {
                return await _distribuidorRepository.ConsultarPorId(id);
            }
            catch (Exception ex)
            {
                await _logService.GravarLog(TipoLogSistema.DistribuidorConsultarPorIdException, id, ex.Message);
            }
            return null;
        }

        public async Task<IEnumerable<Distribuidores>> ConsultaTodos()
        {
            try
            {
                return await _distribuidorRepository.ConsultaTodos();
            }
            catch (Exception ex)
            {
                await _logService.GravarLog(TipoLogSistema.DistribuidorConsultarTodosException, ex.Message);
            }
            return null;
        }

    }
}
