﻿using System;
using System.Collections.Generic;
using System.Text;
using TGS.ValeGas.Service.Interfaces;

namespace TGS.ValeGas.Service.Entidades
{
    public class GovernoService : IGovernoService
    {
    }
}
