﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TGS.ValeGas.Domain.Entidades;
using TGS.ValeGas.Infra.DTOs;
using TGS.ValeGas.Infra.DTOs.Fornecedor;
using TGS.ValeGas.Infra.Interfaces;
using TGS.ValeGas.Repository.Interfaces;
using TGS.ValeGas.Service.Interfaces;
using TGS.ValeGas.Utilitario.Constantes;
using TGS.ValeGas.Utilitario.Enumeradores;
using TGS.ValeGas.Utilitario.Helper;

namespace TGS.ValeGas.Service.Entidades
{
    public class FornecedorService : IFornecedorService
    {
        private readonly IFornecedorRepository _fornecedorRepository;
        private readonly ILogService _logService;

        public FornecedorService(IFornecedorRepository fornecedorRepository, ILogService logService)
        {
            _fornecedorRepository = fornecedorRepository;
            _logService = logService;
        }

        public async Task<Tuple<bool, string>> CadastrarDados(FornecedorCadastroDto fornecedores)
        {
            try
            {
                if (ValidaCNPJ.IsCnpj(fornecedores.CNPJ))
                {
                    var retorno_fornecedor = await _fornecedorRepository.ConsultarPorCNPJ(fornecedores.CNPJ);

                    if (retorno_fornecedor == null)
                    {
                        var entidade = new FornecedoresSelos();
                        entidade.NuDocumento = long.Parse(fornecedores.CNPJ);
                        entidade.CamposExtras = fornecedores.CamposExtras;
                        entidade.NomeFornecedor = fornecedores.NomeFornecedor;
                        entidade.IdEstadoFornecedorSelo = (int)TipoEstado.IdEstadoFornecedorCadastro;
                        entidade.DataOperacao = DateTime.Now;

                        var resultado = await _fornecedorRepository.Cadastrar(entidade);

                        if (resultado == false)
                            throw new Exception("CNPJ já cadastrado");

                        return new Tuple<bool, string>(true, "Cadastro realizado com sucesso.");
                    }
                    else
                    {
                        await _logService.GravarLog(TipoLogSistema.DistribuidorCadastrarDadosException, fornecedores, "CadastrarDados - CNPJ já cadastrado");
                        return new Tuple<bool, string>(false, "CNPJ já cadastrado");
                    }
                }
                else
                {
                    await _logService.GravarLog(TipoLogSistema.FornecedorCadastrarDadosException, fornecedores, "CadastrarDados - CNPJ invalido do fornecedor");
                    return new Tuple<bool, string>(false, "CNPJ inválido");
                }
            }
            catch (Exception ex)
            {
                await _logService.GravarLog(TipoLogSistema.FornecedorCadastrarDadosException, fornecedores, ex.Message);
            }

            return new Tuple<bool, string>(false, "Falha interna, entrar em contato com o administrador");
        }

        public async Task<bool> AlterarDados(FornecedorDto fornecedores)
        {
            bool result = false;

            try
            {
                if (ValidaCNPJ.IsCnpj(fornecedores.CNPJ))
                {
                    var entidade = await _fornecedorRepository.ConsultarPorCNPJ(fornecedores.CNPJ);

                    if (entidade != null)
                    {
                        entidade.NomeFornecedor = fornecedores.NomeFornecedor;
                        entidade.CamposExtras = fornecedores.CamposExtras;
                        entidade.DataOperacao = DateTime.Now;

                        await _fornecedorRepository.Alterar(entidade);
                        result = true;
                    }
                    else
                    {
                        await _logService.GravarLog(TipoLogSistema.FornecedorAlterarDadosCPFException, fornecedores, "AlterarDados - Retornou nulo ao consultar o CNPJ do fornecedor");
                    }
                }
                else
                {
                    await _logService.GravarLog(TipoLogSistema.FornecedorAlterarDadosCPFException, fornecedores, "AlterarDados - CNPJ invalido do fornecedor");
                }
            }
            catch (Exception ex)
            {
                await _logService.GravarLog(TipoLogSistema.FornecedorAlterarDadosCPFException, fornecedores, ex.Message);
            }

            return result;
        }

        public async Task<bool> DeletarDados(string cnpj)
        {
            bool result = false;

            try
            {
                if (ValidaCNPJ.IsCnpj(cnpj))
                {
                    var entidade = await _fornecedorRepository.ConsultarPorCNPJ(cnpj);

                    if (entidade != null)
                    {
                        await _fornecedorRepository.Excluir(cnpj);
                        result = true;
                    }
                    else
                    {
                        await _logService.GravarLog(TipoLogSistema.FornecedorExcluirDadosCPFException, cnpj, "DeletarDados - Retornou nulo ao consultar o CNPJ do fornecedor");
                    }
                }
                else
                {
                    await _logService.GravarLog(TipoLogSistema.FornecedorExcluirDadosCPFException, cnpj, "DeletarDados - CNPJ invalido do fornecedor");
                }
            }
            catch (Exception ex)
            {
                await _logService.GravarLog(TipoLogSistema.FornecedorExcluirDadosCPFException, cnpj, ex.Message);
            }

            return result;
        }

        public async Task<FornecedoresSelos> ConsultarPorCNPJ(string cnpj)
        {
            try
            {
                return await _fornecedorRepository.ConsultarPorCNPJ(cnpj);
            }
            catch (Exception ex)
            {
                await _logService.GravarLog(TipoLogSistema.FornecedorConsultarPorCNPJException, cnpj, ex.Message);
            }
            return null;
        }

        public async Task<FornecedoresSelos> ConsultarPorId(int id)
        {
            try
            {
                return await _fornecedorRepository.ConsultarPorId(id);
            }
            catch (Exception ex)
            {
                await _logService.GravarLog(TipoLogSistema.FornecedorConsultarPorIdException, id, ex.Message);
            }
            return null;
        }

        public async Task<IEnumerable<FornecedoresSelos>> ConsultaTodos()
        {
            try
            {
                return await _fornecedorRepository.ConsultaTodos();
            }
            catch (Exception ex)
            {
                await _logService.GravarLog(TipoLogSistema.FornecedorConsultarTodosException, ex.Message);
            }
            return null;
        }

    }
}
