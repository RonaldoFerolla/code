﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TGS.ValeGas.Domain.Entidades;
using TGS.ValeGas.Infra.DTOs.Beneficiario;
using TGS.ValeGas.Repository.Contexto;
using TGS.ValeGas.Repository.Interfaces;
using TGS.ValeGas.Service.Interfaces;
using TGS.ValeGas.Utilitario.Enumeradores;

namespace TGS.ValeGas.Service.Entidades
{
    public class BeneficiarioService : IBeneficiarioService
    {


        private readonly ILogService _logService;
        private readonly IBeneficiarioRepository _beneficiarioRepository;

        public BeneficiarioService(ILogService logService, IBeneficiarioRepository beneficiarioRepository)
        {
            _logService = logService;
            _beneficiarioRepository = beneficiarioRepository;
        }

        public async Task<IEnumerable<Beneficiarios>> ConsultaTodos()
        {
            try
            {
                return await _beneficiarioRepository.ConsultaTodos();
            }
            catch (Exception ex)
            {
                await _logService.GravarLog(TipoLogSistema.BeneficiarioConsultarTodosException, ex.Message);
            }
            return null;
        }

        public async Task<Beneficiarios> ConsultarPorNIS(string nis)
        {
            try
            {
                return await _beneficiarioRepository.ConsultarPorNIS(nis);
            }
            catch (Exception ex)
            {
                await _logService.GravarLog(TipoLogSistema.BeneficiarioConsultarPorNISException, ex.Message);
            }
            return null;
        }

        public async Task<Beneficiarios> ConsultarPorCPF(string cpf)
        {
            try
            {
                return await _beneficiarioRepository.ConsultarPorCPF(cpf);
            }
            catch (Exception ex)
            {
                await _logService.GravarLog(TipoLogSistema.BeneficiarioConsultarPorCPFException, ex.Message);
            }
            return null;
        }

        public async Task<Beneficiarios> ConsultarPorID(long Id)
        {
            try
            {
                return await _beneficiarioRepository.ConsultarPorID(Id);
            }
            catch (Exception ex)
            {
                await _logService.GravarLog(TipoLogSistema.BeneficiarioConsultarPorIDException, ex.Message);
            }
            return null;
        }

        public async Task<bool> CadastrarDados(BeneficiarioCadastrarDto Beneficiarios)
        {
            bool result = false;
            var entidade = new Beneficiarios();

            try
            {
                var beneficiario = await _beneficiarioRepository.ConsultarPorNIS(Beneficiarios.NIS);
                //busca no governo se o NIS é Ativo

                if (beneficiario.IdBeneficiario == 0)
                {
                    entidade.NuDocumento = long.Parse(Beneficiarios.NIS);
                    entidade.NomeBeneficiario = Beneficiarios.Nome;
                    entidade.IdEstadoBeneficiario = 10;
                    entidade.CamposExtras = "{}";
                    entidade.DataOperacao = DateTime.Now;
                    entidade.IdUsuario = 0;

                    await _beneficiarioRepository.Cadastrar(entidade);

                    result = true;
                }
                else
                {
                    await _logService.GravarLog(TipoLogSistema.BeneficiarioCadastrarDadosException, Beneficiarios, "CadastrarDados - NIS já cadastrado do Beneficiário");
                }

            }
            catch (Exception ex)
            {
                await _logService.GravarLog(TipoLogSistema.BeneficiarioCadastrarDadosException, Beneficiarios, ex.Message);
            }
            return result;
        }

        public async Task<bool> AlterarDados(BeneficiarioCadastrarDto Beneficiarios)
        {
            bool result = false;

            try
            {
                var beneficiario = await _beneficiarioRepository.ConsultarPorNIS(Beneficiarios.NIS);

                if (beneficiario != null && beneficiario.IdBeneficiario > 0)
                {
                    beneficiario.NuDocumento = long.Parse(Beneficiarios.NIS);
                    beneficiario.NomeBeneficiario = Beneficiarios.Nome;
                    beneficiario.IdEstadoBeneficiario = 10;
                    beneficiario.CamposExtras = "{}";
                    beneficiario.DataOperacao = DateTime.Now;
                    beneficiario.IdUsuario = 0;

                    await _beneficiarioRepository.Alterar(beneficiario);
                    result = true;
                }
                else
                {
                    await _logService.GravarLog(TipoLogSistema.BeneficiarioAlterarDadosException, Beneficiarios, "AlterarDados - Retornou nulo ao consultar o NIS do Beneficiário ");
                }

            }
            catch (Exception ex)
            {

                await _logService.GravarLog(TipoLogSistema.BeneficiarioAlterarDadosException, ex.Message);
            }

            return result;
        }

        public async Task<bool> DeletarDados(BeneficiarioCadastrarDto Beneficiarios)
        {
            bool result = false;

            try
            {
                var beneficiario = await _beneficiarioRepository.ConsultarPorNIS(Beneficiarios.NIS);

                if (beneficiario != null && beneficiario.IdBeneficiario > 0)
                {
                    await _beneficiarioRepository.Deletar(beneficiario);
                    result = true;
                }
                else
                {
                    await _logService.GravarLog(TipoLogSistema.BeneficiarioDeletarDadosException, Beneficiarios, "DeletarDados - Retornou nulo ao consultar o NIS do Beneficiário ");
                }

            }
            catch (Exception ex)
            {
                await _logService.GravarLog(TipoLogSistema.BeneficiarioDeletarDadosException, ex.Message);
            }

            return result;
        }
    }
}