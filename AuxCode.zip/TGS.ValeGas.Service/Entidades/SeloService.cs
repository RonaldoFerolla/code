﻿using Newtonsoft.Json;
using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using TGS.ValeGas.Domain.Entidades;
using TGS.ValeGas.Infra.DTOs.Selo;
using TGS.ValeGas.Infra.DTOs.SIMP;
using TGS.ValeGas.Infra.Interfaces;
using TGS.ValeGas.Repository.Interfaces;
using TGS.ValeGas.Service.Interfaces;
using TGS.ValeGas.Utilitario.Constantes;
using TGS.ValeGas.Utilitario.Enumeradores;

namespace TGS.ValeGas.Service.Entidades
{
    public class SeloService : ISeloService
    {
        private readonly ISeloRepository _seloRepository;
        private readonly ILogService _logService;
        private readonly IHttpClientFactory _clientFactory;

        public SeloService(ISeloRepository seloRepository, ILogService logService, IHttpClientFactory clientFactory)
        {
            _seloRepository = seloRepository;
            _logService = logService;
            _clientFactory = clientFactory;
        }

        public async Task<long> CadastrarPedido(SeloPedidoDto seloPedido)
        {
            try
            {

                //Validar pagamento realizado 
                //Validar se Cliente existe 
                //Validar Cadastro do Pedido já realiado

                var item = new[]
                {
                    new{
                        CodProduto = 1,
                        QuantidadeItem = seloPedido.Quantidade 
                        }
                };

                var obj = new
                {
                    NumeroPedido = 30,
                    CodProduto = SIMP.KIT_PRODUTO,
                    NumeroPedidoCliente = 30,
                    Solicitante = new
                    {
                        CodSolicitante = seloPedido.CNPJ //14746470000103
                    },
                    ListaItens = item
                };

                var request = new RequestDto()
                {
                    CodigoCliente = SIMP.COD_CLIENTE,
                    CodigoProduto = SIMP.KIT_PRODUTO,
                    CodigoOperacao = (int)TipoOperacaoSIMP.CadastrarPedido,
                    Content = JsonConvert.SerializeObject(obj)
                };


                var client = _clientFactory.CreateClient("SimpApi");
                var json = JsonConvert.SerializeObject(request);
                var httpContent = new StringContent(json, Encoding.UTF8, "application/json");
                HttpResponseMessage response = await client.PostAsync("api/IntegracaoCliente/ReceberDados", httpContent);
                var responseBody = await response.Content.ReadAsStringAsync();


                if (!response.IsSuccessStatusCode)
                    throw new Exception(responseBody);

                return long.Parse(responseBody);
            }
            catch (Exception ex)
            {
                await _logService.GravarLog(TipoLogSistema.SeloCadastrarPedidoException, seloPedido, ex.Message);
            }

            return -1;
        }

        public async Task<NumeracaoSelos> Consultar(string selo)
        {
            try
            {
                return await _seloRepository.Consultar(selo);
            }
            catch (Exception ex)
            {
                await _logService.GravarLog(TipoLogSistema.SeloConsultarException, selo, ex.Message);
            }
            return null;
        }
    }
}
