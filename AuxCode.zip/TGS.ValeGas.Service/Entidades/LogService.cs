﻿using Newtonsoft.Json;
using System;
using System.Threading.Tasks;
using TGS.ValeGas.Domain.Entidades;
using TGS.ValeGas.Repository.Interfaces;
using TGS.ValeGas.Service.Interfaces;
using TGS.ValeGas.Utilitario.Enumeradores;

namespace TGS.ValeGas.Service.Entidades
{
    public class LogService : ILogService
    {
        private readonly IAsyncRepositorio<LogSistema> _logRepository;

        public LogService(IAsyncRepositorio<LogSistema> logRepository)
        {
            _logRepository = logRepository;
        }

        public async Task GravarLog(TipoLogSistema tipoLog, params object[] args)
        {
            var objLog = FactoryLog(tipoLog, args);
            await Adicionar(objLog);
        }

        private async Task Adicionar(LogSistema entidade)
        {
            await _logRepository.AdicionarAsync(entidade);
        }

        private LogSistema FactoryLog(TipoLogSistema tipoLog, params object[] args)
        {
            var objString = JsonConvert.SerializeObject(args);
            return new LogSistema { CodLogSistema = Enum.GetName(typeof(TipoLogSistema), tipoLog), JsonConteudo = objString, DataOperacao = DateTime.Now };
        }
    }
}
