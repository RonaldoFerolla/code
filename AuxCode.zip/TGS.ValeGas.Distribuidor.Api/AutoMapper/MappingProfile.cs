﻿using AutoMapper;

namespace TGS.ValeGas.Distribuidor.Api.AutoMapper
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            //CreateMap<Proprietarios, ProprietariosDto>().ReverseMap();
        }
    }
}
