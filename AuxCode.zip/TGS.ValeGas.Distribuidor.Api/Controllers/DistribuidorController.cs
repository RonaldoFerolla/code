﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TGS.ValeGas.Infra.DTOs;
using TGS.ValeGas.Infra.DTOs.Distribuidor;
using TGS.ValeGas.Service.Interfaces;

namespace TGS.ValeGas.Distribuidor.Api.Controllers
{
    [ApiController]
    [Consumes("application/json")]
    [Route("api/[controller]")]
    //[Authorize]
    public class DistribuidorController : Controller
    {
        public readonly IMapper _mapper;
        public readonly IDistribuidorService _distribuidorService;

        public DistribuidorController(IMapper mapper, IDistribuidorService distribuidorService)
        {
            _mapper = mapper;
            _distribuidorService = distribuidorService;
        }

        /// <summary>
        /// Cadastrar novo Distribuidor
        /// </summary>
        /// <param name="distribuidor"></param>
        /// <returns>Cadastro realizado com sucesso.</returns>
        /// <response code="201">Cadastro realizado com sucesso.</response>
        /// <response code="400">Falha interna</response>
        /// <response code="401">Token inválido</response>
        /// <response code="403">Token Expirado</response>
        [SwaggerResponse((int)StatusCodes.Status201Created, Type = typeof(string))]
        [SwaggerResponse((int)StatusCodes.Status400BadRequest)]
        [SwaggerResponse((int)StatusCodes.Status401Unauthorized)]
        [SwaggerResponse((int)StatusCodes.Status403Forbidden)]
        [HttpPost("Cadastrar")]
        public async Task<IActionResult> Cadastrar(DistribuidorCadastroDto distribuidor)
        {
            try
            {
                var cadastro_distribuidor = await _distribuidorService.CadastrarDados(distribuidor);

                if (cadastro_distribuidor.Item1 == false)
                    return StatusCode(StatusCodes.Status400BadRequest, cadastro_distribuidor.Item2);

                return StatusCode(StatusCodes.Status200OK, distribuidor);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status400BadRequest, string.Concat("Erro Interno: ", ex.Message));
            }
        }

        /// <summary>
        /// Consultar Todos os distribuidores sem filtro
        /// </summary>
        /// <returns></returns>
        /// <response code="200">Listar de todos os distribuidores</response>
        /// <response code="400">Falha interna</response>
        /// <response code="401">Token inválido</response>
        /// <response code="403">Token Expirado</response>
        [SwaggerResponse((int)StatusCodes.Status200OK, Type = typeof(List<DistribuidorDto>))]
        [SwaggerResponse((int)StatusCodes.Status400BadRequest)]
        [SwaggerResponse((int)StatusCodes.Status401Unauthorized)]
        [SwaggerResponse((int)StatusCodes.Status403Forbidden)]
        [HttpGet("Consultar/Todos")]
        public async Task<IActionResult> Consultar()
        {
            try
            {
                var lista = await _distribuidorService.ConsultaTodos();

                if (lista == null)
                    return StatusCode(StatusCodes.Status400BadRequest, "Falha ao realizar a busca dos Distribuidores");


                return StatusCode(StatusCodes.Status200OK, lista);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status400BadRequest, string.Concat("Erro Interno: ", ex.Message));
            }
        }

        /// <summary>
        /// Consultar distribuidor pelo Cadastro Nacional da Pessoa Jurídica (CNPJ).
        /// </summary>
        /// <param name="cnpj"></param>
        /// <returns></returns>
        /// <response code="200">Consulta por CNPJ realizada com sucesso.</response>
        /// <response code="400">Falha interna</response>
        /// <response code="401">Token inválido</response>
        /// <response code="403">Token Expirado</response>
        [SwaggerResponse((int)StatusCodes.Status200OK, Type = typeof(DistribuidorDto))]
        [SwaggerResponse((int)StatusCodes.Status400BadRequest)]
        [SwaggerResponse((int)StatusCodes.Status401Unauthorized)]
        [SwaggerResponse((int)StatusCodes.Status403Forbidden)]
        [HttpGet("Consultar/CNPJ")]
        public async Task<IActionResult> ConsultarCNPJ(string cnpj)
        {
            try
            {
                var distribuidor = await _distribuidorService.ConsultarPorCNPJ(cnpj);

                if (distribuidor == null)
                    return StatusCode(StatusCodes.Status400BadRequest, "Falha ao realizar a busca dos Distribuidor");


                //Mappaer
                //var objDTO =  _mapper.Map<DistribuidorDto>(distribuidor);

                return StatusCode(StatusCodes.Status200OK, distribuidor);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status400BadRequest, string.Concat("Erro Interno: ", ex.Message));
            }
        }

        /// <summary>
        /// Consultar distribuidor pelo Id cadastrado.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <response code="200">Consultar por ID realizada com sucesso.</response>
        /// <response code="400">Falha interna</response>
        /// <response code="401">Token inválido</response>
        /// <response code="403">Token Expirado</response>
        [SwaggerResponse((int)StatusCodes.Status200OK, Type = typeof(DistribuidorDto))]
        [SwaggerResponse((int)StatusCodes.Status400BadRequest)]
        [SwaggerResponse((int)StatusCodes.Status401Unauthorized)]
        [SwaggerResponse((int)StatusCodes.Status403Forbidden)]
        [HttpGet("Consultar/ID")]
        public async Task<IActionResult> ConsultarId(int id)
        {
            try
            {
                var distribuidor = await _distribuidorService.ConsultarPorId(id);

                if (distribuidor == null)
                    return StatusCode(StatusCodes.Status400BadRequest, "Falha ao realizar a busca dos Distribuidor");


                //Mappaer
                //var objDTO =  _mapper.Map<DistribuidorDto>(distribuidor);

                return StatusCode(StatusCodes.Status200OK, distribuidor);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status400BadRequest, string.Concat("Erro Interno: ", ex.Message));
            }
        }

        /// <summary>
        /// Atualizar dados do distribuidor.
        /// </summary>
        /// <param name="distribuidor"></param>
        /// <returns></returns>
        /// <response code="200">Beneficiario atualizado com sucesso.</response>
        /// <response code="400">Falha interna</response>
        /// <response code="401">Token inválido</response>
        /// <response code="403">Token Expirado</response>
        [SwaggerResponse((int)StatusCodes.Status200OK, Type = typeof(bool))]
        [SwaggerResponse((int)StatusCodes.Status400BadRequest)]
        [SwaggerResponse((int)StatusCodes.Status401Unauthorized)]
        [SwaggerResponse((int)StatusCodes.Status403Forbidden)]
        [HttpPost("Atualizar")]
        public async Task<IActionResult> Atualizar(DistribuidorDto distribuidor)
        {
            try
            {
                var Dadosdistribuidor = await _distribuidorService.AlterarDados(distribuidor);

                if (!Dadosdistribuidor)
                    return StatusCode(StatusCodes.Status400BadRequest, "Falha ao realizar a Alteração de Dados do Distribuidor");

                return StatusCode(StatusCodes.Status200OK, distribuidor);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status400BadRequest, string.Concat("Erro Interno: ", ex.Message));
            }
        }

        /// <summary>
        /// Deletar Distribuidor.
        /// </summary>
        /// <param name="distribuidor"></param>
        /// <returns></returns>
        /// <response code="200">Deletado com sucesso.</response>
        /// <response code="400">Falha interna</response>
        /// <response code="401">Token inválido</response>
        /// <response code="403">Token Expirado</response>
        [SwaggerResponse((int)StatusCodes.Status200OK, Type = typeof(bool))]
        [SwaggerResponse((int)StatusCodes.Status400BadRequest)]
        [SwaggerResponse((int)StatusCodes.Status401Unauthorized)]
        [SwaggerResponse((int)StatusCodes.Status403Forbidden)]
        [HttpDelete("Deletar")]
        public async Task<IActionResult> Deletar(string cnpj)
        {
            try
            {
                var distribuidor = await _distribuidorService.DeletarDados(cnpj);

                if (!distribuidor)
                    return StatusCode(StatusCodes.Status400BadRequest, "Falha ao deletar Dados do Distribuidor");

                return StatusCode(StatusCodes.Status200OK, distribuidor);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status400BadRequest, string.Concat("Erro Interno: ", ex.Message));
            }
        }

        /// <summary>
        /// Recepção do Pedido realizado Distribuidora
        /// </summary>
        /// <param name="pedido"></param>
        /// <returns></returns>
        /// <response code="200">Recepção realizada com sucesso</response>
        /// <response code="400">Falha interna</response>
        /// <response code="401">Token inválido</response>
        /// <response code="403">Token Expirado</response>
        [SwaggerResponse((int)StatusCodes.Status200OK, Type = typeof(bool))]
        [SwaggerResponse((int)StatusCodes.Status400BadRequest)]
        [SwaggerResponse((int)StatusCodes.Status401Unauthorized)]
        [SwaggerResponse((int)StatusCodes.Status403Forbidden)]
        [HttpPost("Pedido/Recepcao")]
        public async Task<IActionResult> PedidoRecepcao(PedidoRecepcaoDto pedido)
        {
            return StatusCode(StatusCodes.Status200OK, true);
        }
    }
}
