using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using TGS.ValeGas.Distribuidor.Api.Config;

namespace TGS.ValeGas.Distribuidor.Api
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //Inje��o de dependencia
            services.ResolverDependencia(Configuration);

            //Banco de dados configura��o
            services.AdicionarDatabaseConfig(Configuration);

            //AutoMapper Configura��o
            services.AdicionarAutoMapperConfig();

            //JWT configura��o
            services.AdicionarJwtBearerConfig(Configuration);

            services.AddControllers();

            //Swagger Configura��o
            services.AddSwaggerGenConfig(Configuration);

            //Refit Configura��o
            services.ClientRefitConfig(Configuration);

            //HttpRequest 
            services.AdicionarHttpClientConfig(Configuration);

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthentication();

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

            app.UseSwagger();

            app.UseSwaggerUI(swagger =>
            {
                swagger.SwaggerEndpoint("v1/swagger.json", "Distribuidor - V1");
            });
        }
    }
}
