﻿using AutoMapper;
using Microsoft.Extensions.DependencyInjection;
using TGS.ValeGas.Distribuidor.Api.AutoMapper;

namespace TGS.ValeGas.Distribuidor.Api.Config
{
    public static class AutoMapperConfig
    {
        public static IServiceCollection AdicionarAutoMapperConfig(this IServiceCollection services)
        {

            var mappingConfig = new MapperConfiguration(mc =>
            {
                mc.AddProfile(new MappingProfile());
            });

            IMapper mapper = mappingConfig.CreateMapper();
            services.AddSingleton(mapper);

            return services;
        }
    }
}
