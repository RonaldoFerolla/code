﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using TGS.ValeGas.Repository.Contexto;

namespace TGS.ValeGas.Distribuidor.Api.Config
{
    public static class DatabaseConfig
    {
        public static IServiceCollection AdicionarDatabaseConfig(this IServiceCollection services, IConfiguration configuration)
        {

            services.AddDbContext<EFContexto>(options =>
                options.UseSqlServer(configuration.GetConnectionString("DefaultConnection")));

            return services;
        }
    }
}
