﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Net.Http.Headers;

namespace TGS.ValeGas.Distribuidor.Api.Config
{
    public static class HttpClientConfiguration
    {
        public static IServiceCollection AdicionarHttpClientConfig(this IServiceCollection services, IConfiguration configuration)
        {

            services.AddHttpClient("SimpApi", c =>
            {
                c.BaseAddress = new Uri(configuration["UrlSimp"]);
                c.DefaultRequestHeaders.Accept.Clear();
                c.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            });

            return services;
        }
    }
}
