﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Refit;
using System;
using System.Net.Http.Headers;
using TGS.ValeGas.Infra.Interfaces;

namespace TGS.ValeGas.Distribuidor.Api.Config
{
    public static class RefitConfig
    {
        public static IServiceCollection ClientRefitConfig(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddRefitClient<IClientSimpApi>()
            .ConfigureHttpClient(
                config =>
                {
                    config.DefaultRequestHeaders.Accept.Clear();
                    //config.DefaultRequestHeaders.Add("Accept", "application/json");
                    //config.DefaultRequestHeaders.Add("Content-Type", "application/json");
                    config.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    //config.DefaultRequestVersion = new Version(2, 0);
                    config.BaseAddress = new Uri(configuration["UrlSimp"]);
                });


            return services;
        }
    }
}
