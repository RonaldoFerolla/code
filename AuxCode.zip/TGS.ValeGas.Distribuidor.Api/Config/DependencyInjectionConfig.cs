﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using TGS.ValeGas.Repository;
using TGS.ValeGas.Repository.Entidades;
using TGS.ValeGas.Repository.Interfaces;
using TGS.ValeGas.Service.Entidades;
using TGS.ValeGas.Service.Interfaces;

namespace TGS.ValeGas.Distribuidor.Api.Config
{
    public static class DependencyInjectionConfig
    {
        public static IServiceCollection ResolverDependencia(this IServiceCollection services, IConfiguration configuration)
        {
            // Repository
            services.AddScoped(typeof(IAsyncRepositorio<>), typeof(BaseRepositorio<>));
            services.AddScoped(typeof(IDistribuidorRepository), typeof(DistribuidorRepository));

            // Services
            services.AddScoped<IDistribuidorService, DistribuidorService>();
            services.AddScoped<ILogService, LogService>();

            return services;
        }
    }
}
