﻿using System;
using System.Collections.Generic;


namespace TGS.ValeGas.Domain.Entidades
{
    public partial class Usuarios
    {
        public Usuarios()
        {
            Beneficiarios = new HashSet<Beneficiarios>();
            Distribuidores = new HashSet<Distribuidores>();
            FornecedoresSelos = new HashSet<FornecedoresSelos>();
            NumeracaoSelos = new HashSet<NumeracaoSelos>();
            NumeracaoSelosBeneficiarios = new HashSet<NumeracaoSelosBeneficiarios>();
            Revendedores = new HashSet<Revendedores>();
        }

        public long IdUsuario { get; set; }
        public string NomeUsuario { get; set; }
        public string Email { get; set; }
        public DateTime DataOperacao { get; set; }
        public long IdUsuarioCadastro { get; set; }
        public string IdUsuarioIdentity { get; set; }

        public virtual AspNetUsers IdUsuarioIdentityNavigation { get; set; }
        public virtual ICollection<Beneficiarios> Beneficiarios { get; set; }
        public virtual ICollection<Distribuidores> Distribuidores { get; set; }
        public virtual ICollection<FornecedoresSelos> FornecedoresSelos { get; set; }
        public virtual ICollection<NumeracaoSelos> NumeracaoSelos { get; set; }
        public virtual ICollection<NumeracaoSelosBeneficiarios> NumeracaoSelosBeneficiarios { get; set; }
        public virtual ICollection<Revendedores> Revendedores { get; set; }
    }
}
