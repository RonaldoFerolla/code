﻿using System;

namespace TGS.ValeGas.Domain.Entidades
{
    public partial class NumeracaoSelosEstados
    {
        public long IdEstados { get; set; }
        public long IdNumeroSelo { get; set; }
        public int IdEstadoSelo { get; set; }
        public DateTime DataOperacao { get; set; }
        public long IdUsuario { get; set; }

        public virtual EstadosNumeracaoSelosPC IdEstadoSeloNavigation { get; set; }
        public virtual NumeracaoSelos IdNumeroSeloNavigation { get; set; }
    }
}
