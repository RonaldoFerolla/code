﻿using System.Collections.Generic;


namespace TGS.ValeGas.Domain.Entidades
{
    public partial class EstadosNumeracaoSelosPC
    {
        public EstadosNumeracaoSelosPC()
        {
            NumeracaoSelos = new HashSet<NumeracaoSelos>();
            NumeracaoSelosEstados = new HashSet<NumeracaoSelosEstados>();
        }

        public int IdEstadoSelo { get; set; }
        public string Descricao { get; set; }

        public virtual ICollection<NumeracaoSelos> NumeracaoSelos { get; set; }
        public virtual ICollection<NumeracaoSelosEstados> NumeracaoSelosEstados { get; set; }
    }
}
