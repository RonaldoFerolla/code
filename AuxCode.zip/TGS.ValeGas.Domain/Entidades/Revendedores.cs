﻿using System;
using System.Collections.Generic;


namespace TGS.ValeGas.Domain.Entidades
{
    public partial class Revendedores
    {
        public Revendedores()
        {
            NumeracaoSelos = new HashSet<NumeracaoSelos>();
            RevendedoresEstados = new HashSet<RevendedoresEstados>();
        }

        public long IdRevendedor { get; set; }
        public long NuDocumento { get; set; }
        public string NomeRevendedor { get; set; }
        public string CamposExtras { get; set; }
        public int IdEstadoRevendedor { get; set; }
        public DateTime DataOperacao { get; set; }
        public long IdUsuario { get; set; }

        public virtual EstadosRevendedoresPC IdEstadoRevendedorNavigation { get; set; }
        public virtual Usuarios IdUsuarioNavigation { get; set; }
        public virtual ICollection<NumeracaoSelos> NumeracaoSelos { get; set; }
        public virtual ICollection<RevendedoresEstados> RevendedoresEstados { get; set; }
    }
}
