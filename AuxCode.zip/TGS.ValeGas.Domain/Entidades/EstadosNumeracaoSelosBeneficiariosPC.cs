﻿using System.Collections.Generic;


namespace TGS.ValeGas.Domain.Entidades
{
    public partial class EstadosNumeracaoSelosBeneficiariosPC
    {
        public EstadosNumeracaoSelosBeneficiariosPC()
        {
            NumeracaoSelosBeneficiarios = new HashSet<NumeracaoSelosBeneficiarios>();
            NumeracaoSelosBeneficiariosEstados = new HashSet<NumeracaoSelosBeneficiariosEstados>();
        }

        public int IdEstadoNumeracaoSeloBeneficiario { get; set; }
        public string Descricao { get; set; }

        public virtual ICollection<NumeracaoSelosBeneficiarios> NumeracaoSelosBeneficiarios { get; set; }
        public virtual ICollection<NumeracaoSelosBeneficiariosEstados> NumeracaoSelosBeneficiariosEstados { get; set; }
    }
}
