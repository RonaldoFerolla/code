﻿using System;

namespace TGS.ValeGas.Domain.Entidades
{
    public partial class DistribuidoresEstados
    {
        public long IdEstado { get; set; }
        public long IdDistribuidor { get; set; }
        public int IdEstadoDistribuidor { get; set; }
        public DateTime DataOperacao { get; set; }
        public long IdUsuario { get; set; }

        public virtual Distribuidores IdDistribuidorNavigation { get; set; }
        public virtual EstadosDistribuidoresPC IdEstadoDistribuidorNavigation { get; set; }
    }
}
