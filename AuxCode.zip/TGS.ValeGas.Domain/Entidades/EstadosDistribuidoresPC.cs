﻿using System.Collections.Generic;


namespace TGS.ValeGas.Domain.Entidades
{
    public partial class EstadosDistribuidoresPC
    {
        public EstadosDistribuidoresPC()
        {
            Distribuidores = new HashSet<Distribuidores>();
            DistribuidoresEstados = new HashSet<DistribuidoresEstados>();
        }

        public int IdEstadoDistribuidor { get; set; }
        public string Descricao { get; set; }

        public virtual ICollection<Distribuidores> Distribuidores { get; set; }
        public virtual ICollection<DistribuidoresEstados> DistribuidoresEstados { get; set; }
    }
}
