﻿using System.Collections.Generic;


namespace TGS.ValeGas.Domain.Entidades
{
    public partial class EstadosFornecedoresSelosPC
    {
        public EstadosFornecedoresSelosPC()
        {
            FornecedoresSelos = new HashSet<FornecedoresSelos>();
            FornecedoresSelosEstados = new HashSet<FornecedoresSelosEstados>();
        }

        public int IdEstadoFornecedorSelo { get; set; }
        public string Descricao { get; set; }

        public virtual ICollection<FornecedoresSelos> FornecedoresSelos { get; set; }
        public virtual ICollection<FornecedoresSelosEstados> FornecedoresSelosEstados { get; set; }
    }
}
