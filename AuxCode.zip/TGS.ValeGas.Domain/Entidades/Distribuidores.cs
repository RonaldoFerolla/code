﻿using System;
using System.Collections.Generic;

namespace TGS.ValeGas.Domain.Entidades
{
    public partial class Distribuidores
    {
        public Distribuidores()
        {
            DistribuidoresEstados = new HashSet<DistribuidoresEstados>();
            NumeracaoSelos = new HashSet<NumeracaoSelos>();
        }

        public long IdDistribuidor { get; set; }
        public long NuDocumento { get; set; }
        public string NomeDistribuidor { get; set; }
        public string CamposExtras { get; set; }
        public int IdEstadoDistribuidor { get; set; }
        public DateTime DataOperacao { get; set; }
        public long IdUsuario { get; set; }

        public virtual EstadosDistribuidoresPC IdEstadoDistribuidorNavigation { get; set; }
        public virtual Usuarios IdUsuarioNavigation { get; set; }
        public virtual ICollection<DistribuidoresEstados> DistribuidoresEstados { get; set; }
        public virtual ICollection<NumeracaoSelos> NumeracaoSelos { get; set; }
    }
}
