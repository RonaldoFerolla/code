﻿using System;
using System.Collections.Generic;


namespace TGS.ValeGas.Domain.Entidades
{
    public partial class EstadosRevendedoresPC
    {
        public EstadosRevendedoresPC()
        {
            Revendedores = new HashSet<Revendedores>();
            RevendedoresEstados = new HashSet<RevendedoresEstados>();
        }

        public int IdEstadoRevendedor { get; set; }
        public string Descricao { get; set; }

        public virtual ICollection<Revendedores> Revendedores { get; set; }
        public virtual ICollection<RevendedoresEstados> RevendedoresEstados { get; set; }
    }
}
