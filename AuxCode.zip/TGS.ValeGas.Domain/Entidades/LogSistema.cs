﻿using System;


namespace TGS.ValeGas.Domain.Entidades
{
    public partial class LogSistema
    {
        public long IdLogSistema { get; set; }
        public string CodLogSistema { get; set; }
        public string JsonConteudo { get; set; }
        public DateTime DataOperacao { get; set; }
    }
}
