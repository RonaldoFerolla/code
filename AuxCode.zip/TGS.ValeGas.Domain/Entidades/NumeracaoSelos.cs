﻿using System;
using System.Collections.Generic;


namespace TGS.ValeGas.Domain.Entidades
{
    public partial class NumeracaoSelos
    {
        public NumeracaoSelos()
        {
            NumeracaoSelosBeneficiarios = new HashSet<NumeracaoSelosBeneficiarios>();
        }

        public long IdNumeroSelo { get; set; }
        public long NumeroSelo { get; set; }
        public string Selo { get; set; }
        public long IdFornecedorSelo { get; set; }
        public long IdDistribuidor { get; set; }
        public long? IdRevendedor { get; set; }
        public string CamposExtras { get; set; }
        public int IdEstadoSelo { get; set; }
        public DateTime DataOperacao { get; set; }
        public long IdUsuario { get; set; }

        public virtual Distribuidores IdDistribuidorNavigation { get; set; }
        public virtual EstadosNumeracaoSelosPC IdEstadoSeloNavigation { get; set; }
        public virtual Revendedores IdRevendedorNavigation { get; set; }
        public virtual Usuarios IdUsuarioNavigation { get; set; }
        public virtual NumeracaoSelosEstados NumeracaoSelosEstados { get; set; }
        public virtual ICollection<NumeracaoSelosBeneficiarios> NumeracaoSelosBeneficiarios { get; set; }
    }
}
