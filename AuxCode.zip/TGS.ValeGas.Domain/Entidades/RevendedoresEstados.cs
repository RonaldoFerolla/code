﻿using System;

namespace TGS.ValeGas.Domain.Entidades
{
    public partial class RevendedoresEstados
    {
        public long IdEstado { get; set; }
        public long IdRevendedor { get; set; }
        public int IdEstadoRevendedor { get; set; }
        public DateTime DataOperacao { get; set; }
        public long IdUsuario { get; set; }

        public virtual EstadosRevendedoresPC IdEstadoRevendedorNavigation { get; set; }
        public virtual Revendedores IdRevendedorNavigation { get; set; }
    }
}
