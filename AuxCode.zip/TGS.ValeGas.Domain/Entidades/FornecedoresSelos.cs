﻿using System;
using System.Collections.Generic;


namespace TGS.ValeGas.Domain.Entidades
{
    public partial class FornecedoresSelos
    {
        public FornecedoresSelos()
        {
            FornecedoresSelosEstados = new HashSet<FornecedoresSelosEstados>();
        }

        public long IdFornecedorSelo { get; set; }
        public long NuDocumento { get; set; }
        public string CamposExtras { get; set; }
        public string NomeFornecedor { get; set; }
        public int IdEstadoFornecedorSelo { get; set; }
        public DateTime DataOperacao { get; set; }
        public long IdUsuario { get; set; }

        public virtual EstadosFornecedoresSelosPC IdEstadoFornecedorSeloNavigation { get; set; }
        public virtual Usuarios IdUsuarioNavigation { get; set; }
        public virtual ICollection<FornecedoresSelosEstados> FornecedoresSelosEstados { get; set; }
    }
}
