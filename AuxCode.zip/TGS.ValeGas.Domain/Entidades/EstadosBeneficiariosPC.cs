﻿using System.Collections.Generic;

namespace TGS.ValeGas.Domain.Entidades
{
    public partial class EstadosBeneficiariosPC
    {
        public EstadosBeneficiariosPC()
        {
            Beneficiarios = new HashSet<Beneficiarios>();
            BeneficiariosEstados = new HashSet<BeneficiariosEstados>();
        }

        public int IdEstadoBeneficiario { get; set; }
        public string Descricao { get; set; }

        public virtual ICollection<Beneficiarios> Beneficiarios { get; set; }
        public virtual ICollection<BeneficiariosEstados> BeneficiariosEstados { get; set; }
    }
}
