﻿using System;
using System.Collections.Generic;


namespace TGS.ValeGas.Domain.Entidades
{
    public partial class NumeracaoSelosBeneficiarios
    {
        public NumeracaoSelosBeneficiarios()
        {
            NumeracaoSelosBeneficiariosEstados = new HashSet<NumeracaoSelosBeneficiariosEstados>();
        }

        public long IdNumeracaoSeloBeneficiario { get; set; }
        public long IdNumeroSelo { get; set; }
        public long IdBeneficiario { get; set; }
        public string CamposExtras { get; set; }
        public int IdEstadoNumeracaoSeloBeneficiario { get; set; }
        public DateTime DataOperacao { get; set; }
        public long IdUsuario { get; set; }

        public virtual Beneficiarios IdBeneficiarioNavigation { get; set; }
        public virtual EstadosNumeracaoSelosBeneficiariosPC IdEstadoNumeracaoSeloBeneficiarioNavigation { get; set; }
        public virtual NumeracaoSelos IdNumeroSeloNavigation { get; set; }
        public virtual Usuarios IdUsuarioNavigation { get; set; }
        public virtual ICollection<NumeracaoSelosBeneficiariosEstados> NumeracaoSelosBeneficiariosEstados { get; set; }
    }
}
