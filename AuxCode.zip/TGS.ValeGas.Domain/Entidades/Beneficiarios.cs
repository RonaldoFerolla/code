﻿using System;
using System.Collections.Generic;


namespace TGS.ValeGas.Domain.Entidades
{
    public partial class Beneficiarios
    {
        public Beneficiarios()
        {
            BeneficiariosEstados = new HashSet<BeneficiariosEstados>();
            NumeracaoSelosBeneficiarios = new HashSet<NumeracaoSelosBeneficiarios>();
        }

        public long IdBeneficiario { get; set; }
        public long NuDocumento { get; set; }
        public string CamposExtras { get; set; }
        public int IdEstadoBeneficiario { get; set; }
        public DateTime DataOperacao { get; set; }
        public long IdUsuario { get; set; }
        public string NomeBeneficiario { get; set; }


        public virtual EstadosBeneficiariosPC IdEstadoBeneficiarioNavigation { get; set; }
        public virtual Usuarios IdUsuarioNavigation { get; set; }
        public virtual ICollection<BeneficiariosEstados> BeneficiariosEstados { get; set; }
        public virtual ICollection<NumeracaoSelosBeneficiarios> NumeracaoSelosBeneficiarios { get; set; }
    }
}
