﻿using System;


namespace TGS.ValeGas.Domain.Entidades
{
    public partial class NumeracaoSelosBeneficiariosEstados
    {
        public long IdEstado { get; set; }
        public long IdNumeracaoSeloBeneficiario { get; set; }
        public int IdEstadoNumeracaoSeloBeneficiario { get; set; }
        public DateTime DataOperacao { get; set; }
        public long IdUsuario { get; set; }

        public virtual EstadosNumeracaoSelosBeneficiariosPC IdEstadoNumeracaoSeloBeneficiarioNavigation { get; set; }
        public virtual NumeracaoSelosBeneficiarios IdNumeracaoSeloBeneficiarioNavigation { get; set; }
    }
}
