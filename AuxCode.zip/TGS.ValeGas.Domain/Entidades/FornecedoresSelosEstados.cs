﻿using System;


namespace TGS.ValeGas.Domain.Entidades
{
    public partial class FornecedoresSelosEstados
    {
        public long IdEstado { get; set; }
        public long IdFornecedorSelo { get; set; }
        public int IdEstadoFornecedorSelo { get; set; }
        public DateTime DataOperacao { get; set; }
        public long IdUsuario { get; set; }

        public virtual EstadosFornecedoresSelosPC IdEstadoFornecedorSeloNavigation { get; set; }
        public virtual FornecedoresSelos IdFornecedorSeloNavigation { get; set; }
    }
}
