﻿using System;


namespace TGS.ValeGas.Domain.Entidades
{
    public partial class BeneficiariosEstados
    {
        public long IdEstado { get; set; }
        public long IdBeneficiario { get; set; }
        public int IdEstadoBeneficiario { get; set; }
        public DateTime DataOperacao { get; set; }
        public long IdUsuario { get; set; }

        public virtual Beneficiarios IdBeneficiarioNavigation { get; set; }
        public virtual EstadosBeneficiariosPC IdEstadoBeneficiarioNavigation { get; set; }
    }
}
