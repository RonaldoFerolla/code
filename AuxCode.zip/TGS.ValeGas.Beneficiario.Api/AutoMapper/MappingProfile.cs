﻿using AutoMapper;

namespace TGS.ValeGas.Beneficiario.Api.AutoMapper
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            //CreateMap<Proprietarios, ProprietariosDto>().ReverseMap();
        }
    }
}
