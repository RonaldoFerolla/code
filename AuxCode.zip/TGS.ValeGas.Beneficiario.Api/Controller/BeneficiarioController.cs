﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using TGS.ValeGas.Infra.DTOs.Beneficiario;
using TGS.ValeGas.Service.Interfaces;

namespace TGS.ValeGas.Beneficiario.Api.Controller
{
    [ApiController]
    [Consumes("application/json")]
    [Route("api/[controller]")]
    //[Authorize]
    public class BeneficiarioController : ControllerBase
    {
        public readonly IMapper _mapper;
        public readonly IBeneficiarioService _beneficiarioService;

        public BeneficiarioController(IMapper mapper, IBeneficiarioService beneficiarioService)
        {
            _mapper = mapper;
            _beneficiarioService = beneficiarioService;
        }

        /// <summary>
        /// Cadastrar novo Beneficiario
        /// </summary>
        /// <param name="beneficiario"></param>
        /// <returns>Cadastro realizado com sucesso.</returns>
        /// <response code="201">Cadastro realizado com sucesso.</response>
        /// <response code="400">Falha interna</response>
        /// <response code="401">Token inválido</response>
        /// <response code="403">Token Expirado</response>
        [SwaggerResponse((int)StatusCodes.Status201Created,Type =typeof(string))]
        [SwaggerResponse((int)StatusCodes.Status400BadRequest)]
        [SwaggerResponse((int)StatusCodes.Status401Unauthorized)]
        [SwaggerResponse((int)StatusCodes.Status403Forbidden)]
        //[Authorize(Roles = "SystemDmyrann")]
        [HttpPost("Cadastrar")]
        public async Task<IActionResult> Cadastrar(BeneficiarioCadastrarDto beneficiario)
        {
            try
            {
                var DadosBeneficiario = await _beneficiarioService.CadastrarDados(beneficiario);

                if (!DadosBeneficiario)
                    return StatusCode(StatusCodes.Status400BadRequest, "Falha ao realizar o Cadastro de Dados do beneficiário");

                return StatusCode(StatusCodes.Status200OK, beneficiario);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status400BadRequest, string.Concat("Erro Interno: ", ex.Message));
            }
        }

        /// <summary>
        /// Consultar Todos os beneficiarios sem filtro
        /// </summary>
        /// <returns></returns>
        /// <response code="200">Listar de todos os beneficiarios</response>
        /// <response code="400">Falha interna</response>
        /// <response code="401">Token inválido</response>
        /// <response code="403">Token Expirado</response>
        [SwaggerResponse((int)StatusCodes.Status200OK, Type = typeof(List<BeneficiarioDto>))]
        [SwaggerResponse((int)StatusCodes.Status400BadRequest)]
        [SwaggerResponse((int)StatusCodes.Status401Unauthorized)]
        [SwaggerResponse((int)StatusCodes.Status403Forbidden)]
        //[Authorize(Roles = "SystemDmyrann")]
        [HttpGet("Consultar/Todos")]
        public async Task<IActionResult> Consultar()
        {
            try
            {
                var lista = await _beneficiarioService.ConsultaTodos();

                if (lista == null)
                    return StatusCode(StatusCodes.Status400BadRequest, "Falha ao realizar a busca dos Beneficiarios");


                return StatusCode(StatusCodes.Status200OK, lista);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status400BadRequest, string.Concat("Erro Interno: ", ex.Message));
            }
        }

        /// <summary>
        /// Consultar Beneficiario pelo Número de Identificação Social (NIS).
        /// </summary>
        /// <param name="nis"></param>
        /// <returns></returns>
        /// <response code="200">Consultar por NIS realizada com sucesso.</response>
        /// <response code="400">Falha interna</response>
        /// <response code="401">Token inválido</response>
        /// <response code="403">Token Expirado</response>
        [SwaggerResponse((int)StatusCodes.Status200OK, Type = typeof(BeneficiarioDto))]
        [SwaggerResponse((int)StatusCodes.Status400BadRequest)]
        [SwaggerResponse((int)StatusCodes.Status401Unauthorized)]
        [SwaggerResponse((int)StatusCodes.Status403Forbidden)]
        //[Authorize(Roles = "SystemDmyrann")]
        [HttpGet("Consultar/NIS")]
        public async Task<IActionResult> ConsultarNIS(string nis)
        {
            try
            {
                var beneficiario = await _beneficiarioService.ConsultarPorNIS(nis);

                if (beneficiario == null)
                    return StatusCode(StatusCodes.Status400BadRequest, "Falha ao realizar a busca dos Beneficiarios");

                return StatusCode(StatusCodes.Status200OK, beneficiario);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status400BadRequest, string.Concat("Erro Interno: ", ex.Message));
            }
        }

        /// <summary>
        /// Consultar Beneficiario pelo Cadastro de Pessoas Físicas (CPF).
        /// </summary>
        /// <param name="cpf"></param>
        /// <returns></returns>
        /// <response code="200">Consultar por CPF realizada com sucesso.</response>
        /// <response code="400">Falha interna</response>
        /// <response code="401">Token inválido</response>
        /// <response code="403">Token Expirado</response>
        [SwaggerResponse((int)StatusCodes.Status200OK, Type = typeof(BeneficiarioDto))]
        [SwaggerResponse((int)StatusCodes.Status400BadRequest)]
        [SwaggerResponse((int)StatusCodes.Status401Unauthorized)]
        [SwaggerResponse((int)StatusCodes.Status403Forbidden)]
        //[Authorize(Roles = "SystemDmyrann")]
        [HttpGet("Consultar/CPF")]
        public async Task<IActionResult> ConsultarCPF(string cpf)
        {
            try
            {
                var beneficiario = await _beneficiarioService.ConsultarPorCPF(cpf);

                if (beneficiario == null)
                    return StatusCode(StatusCodes.Status400BadRequest, "Falha ao realizar a busca dos Beneficiarios");

                return StatusCode(StatusCodes.Status200OK, beneficiario);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status400BadRequest, string.Concat("Erro Interno: ", ex.Message));
            }
        }

        /// <summary>
        /// Consultar Beneficiario pelo Id cadastrado.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        /// <response code="200">Consultar por ID realizada com sucesso.</response>
        /// <response code="400">Falha interna</response>
        /// <response code="401">Token inválido</response>
        /// <response code="403">Token Expirado</response>
        [SwaggerResponse((int)StatusCodes.Status200OK, Type = typeof(BeneficiarioDto))]
        [SwaggerResponse((int)StatusCodes.Status400BadRequest)]
        [SwaggerResponse((int)StatusCodes.Status401Unauthorized)]
        [SwaggerResponse((int)StatusCodes.Status403Forbidden)]
        //[Authorize(Roles = "SystemDmyrann")]
        [HttpGet("Consultar/ID")]
        public async Task<IActionResult> ConsultarId(string id)
        {
            try
            {
                var beneficiario = await _beneficiarioService.ConsultarPorID(long.Parse(id));

                if (beneficiario == null)
                    return StatusCode(StatusCodes.Status400BadRequest, "Falha ao realizar a busca dos Beneficiarios");

                return StatusCode(StatusCodes.Status200OK, beneficiario);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status400BadRequest, string.Concat("Erro Interno: ", ex.Message));
            }
        }

        /// <summary>
        /// Atualizar dados do Beneficiario.
        /// </summary>
        /// <param name="beneficiario"></param>
        /// <returns></returns>
        /// <response code="200">Beneficiario atualizado com sucesso.</response>
        /// <response code="400">Falha interna</response>
        /// <response code="401">Token inválido</response>
        /// <response code="403">Token Expirado</response>
        [SwaggerResponse((int)StatusCodes.Status200OK, Type = typeof(bool))]
        [SwaggerResponse((int)StatusCodes.Status400BadRequest)]
        [SwaggerResponse((int)StatusCodes.Status401Unauthorized)]
        [SwaggerResponse((int)StatusCodes.Status403Forbidden)]
        //[Authorize(Roles = "SystemDmyrann")]
        [HttpPost("Atualizar")]
        public async Task<IActionResult> Atualizar(BeneficiarioCadastrarDto beneficiario)
        {
            try
            {
                var DadosBeneficiario = await _beneficiarioService.AlterarDados(beneficiario);

                if (!DadosBeneficiario)
                    return StatusCode(StatusCodes.Status400BadRequest, "Falha ao realizar o Alteração de Dados do beneficiário");

                return StatusCode(StatusCodes.Status200OK, beneficiario);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status400BadRequest, string.Concat("Erro Interno: ", ex.Message));
            }
        }

        /// <summary>
        /// Remever Beneficiario.
        /// </summary>
        /// <param name="beneficiario"></param>
        /// <returns></returns>
        /// <response code="200">Deletado com sucesso.</response>
        /// <response code="400">Falha interna</response>
        /// <response code="401">Token inválido</response>
        /// <response code="403">Token Expirado</response>
        [SwaggerResponse((int)StatusCodes.Status200OK, Type = typeof(bool))]
        [SwaggerResponse((int)StatusCodes.Status400BadRequest)]
        [SwaggerResponse((int)StatusCodes.Status401Unauthorized)]
        [SwaggerResponse((int)StatusCodes.Status403Forbidden)]
        //[Authorize(Roles = "SystemDmyrann")]
        [HttpDelete("Deletar")]
        public async Task<IActionResult> Deletar(BeneficiarioCadastrarDto beneficiario)
        {
            try
            {
                var DadosBeneficiario = await _beneficiarioService.DeletarDados(beneficiario);

                if (!DadosBeneficiario)
                    return StatusCode(StatusCodes.Status400BadRequest, "Falha ao realizar o Delete de Dados do beneficiário");

                return StatusCode(StatusCodes.Status200OK, beneficiario);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status400BadRequest, string.Concat("Erro Interno: ", ex.Message));
            }
        }
    }
}
