﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using TGS.ValeGas.Repository;
using TGS.ValeGas.Repository.Entidades;
using TGS.ValeGas.Repository.Interfaces;
using TGS.ValeGas.Service.Entidades;
using TGS.ValeGas.Service.Interfaces;

namespace TGS.ValeGas.Beneficiario.Api.Config
{
    public static class DependencyInjectionConfig
    {
        public static IServiceCollection ResolverDependencia(this IServiceCollection services, IConfiguration configuration)
        {
            // Repository
            services.AddScoped(typeof(IAsyncRepositorio<>), typeof(BaseRepositorio<>));
            services.AddScoped(typeof(IBeneficiarioRepository), typeof(BeneficiarioRepository));

            // Services
            services.AddScoped<IBeneficiarioService, BeneficiarioService>();
            services.AddScoped<ILogService, LogService>();

            return services;
        }
    }
}
