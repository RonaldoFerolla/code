﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Net.Http;
using TGS.ValeGas.Repository;
using TGS.ValeGas.Repository.Entidades;
using TGS.ValeGas.Repository.Interfaces;
using TGS.ValeGas.Service.Entidades;
using TGS.ValeGas.Service.Interfaces;

namespace TGS.ValeGas.Selo.Api.Config
{
    public static class DependencyInjectionConfig
    {
        public static IServiceCollection ResolverDependencia(this IServiceCollection services, IConfiguration configuration)
        {
            // Repository
            services.AddScoped(typeof(IAsyncRepositorio<>), typeof(BaseRepositorio<>));
            services.AddScoped(typeof(ISeloRepository), typeof(SeloRepository));

            // Services
            services.AddScoped<ISeloService, SeloService>();
            services.AddScoped<ILogService, LogService>();


            services.AddHttpClient<SeloService>();

            //services.AddScoped(typeof(IHttpClientFactory));

            //services.AddHttpClient<IHttpClientFactory>();
            return services;
        }
    }
}
