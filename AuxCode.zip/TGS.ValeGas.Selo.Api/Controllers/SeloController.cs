﻿using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Threading.Tasks;
using TGS.ValeGas.Infra.DTOs.Selo;
using TGS.ValeGas.Service.Interfaces;

namespace TGS.ValeGas.Selo.Api.Controllers
{
    [ApiController]
    [Consumes("application/json")]
    [Route("api/[controller]")]
    //[Authorize]
    public class SeloController : Controller
    {
        public readonly IMapper _mapper;
        public readonly ISeloService _seloService;

        public SeloController(IMapper mapper, ISeloService seloService)
        {
            _mapper = mapper;
            _seloService = seloService;
        }

        /// <summary>
        /// Consultar Selo pelo Número de Identificação.
        /// </summary>
        /// <param name="selo"></param>
        /// <returns></returns>
        /// <response code="200">Consultar Selo pelo Número de Identificação.</response>
        /// <response code="400">Falha interna</response>
        /// <response code="401">Token inválido</response>
        /// <response code="403">Token Expirado</response>
        [SwaggerResponse((int)StatusCodes.Status200OK, Type = typeof(SeloDto))]
        [SwaggerResponse((int)StatusCodes.Status400BadRequest)]
        [SwaggerResponse((int)StatusCodes.Status401Unauthorized)]
        [SwaggerResponse((int)StatusCodes.Status403Forbidden)]
        [HttpGet("Consultar")]
        public async Task<IActionResult> Consultar(string selo)
        {
            try
            {
                var numeracaoSelos = await _seloService.Consultar(selo);

                if (numeracaoSelos == null)
                    return StatusCode(StatusCodes.Status400BadRequest, "Numeração Selo");


                return StatusCode(StatusCodes.Status200OK, numeracaoSelos);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status400BadRequest, string.Concat("Erro Interno: ", ex.Message));
            }
        }


        /// <summary>
        /// Estravio do Selo
        /// </summary>
        /// <param name="selo"></param>
        /// <returns></returns>
        /// <response code="200">Notificação de estravio realizado com sucesso</response>
        /// <response code="400">Falha interna</response>
        /// <response code="401">Token inválido</response>
        /// <response code="403">Token Expirado</response>
        [SwaggerResponse((int)StatusCodes.Status200OK, Type = typeof(bool))]
        [SwaggerResponse((int)StatusCodes.Status400BadRequest)]
        [SwaggerResponse((int)StatusCodes.Status401Unauthorized)]
        [SwaggerResponse((int)StatusCodes.Status403Forbidden)]
        [HttpPost("Estravio")]
        public async Task<IActionResult> SeloEstraviado(SeloEstravioDto selo)
        {
            return StatusCode(StatusCodes.Status200OK, true);
        }


        /// <summary>
        /// Selo vendido sem Beneficio
        /// </summary>
        /// <param name="selo"></param>
        /// <returns></returns>
        /// <response code="200">Notificação venda sem beneficiario</response>
        /// <response code="400">Falha interna</response>
        /// <response code="401">Token inválido</response>
        /// <response code="403">Token Expirado</response>
        [SwaggerResponse((int)StatusCodes.Status200OK, Type = typeof(bool))]
        [SwaggerResponse((int)StatusCodes.Status400BadRequest)]
        [SwaggerResponse((int)StatusCodes.Status401Unauthorized)]
        [SwaggerResponse((int)StatusCodes.Status403Forbidden)]
        [HttpPost("SemBeneficiario")]
        public async Task<IActionResult> SemBeneficiario(SeloDto selo)
        {
            return StatusCode(StatusCodes.Status200OK, true);
        }

        /// <summary>
        /// Selo vendido com Beneficio
        /// </summary>
        /// <param name="selo"></param>
        /// <returns></returns>
        /// <response code="200">Notificação venda com beneficiario</response>
        /// <response code="400">Falha interna</response>
        /// <response code="401">Token inválido</response>
        /// <response code="403">Token Expirado</response>
        [SwaggerResponse((int)StatusCodes.Status200OK, Type = typeof(bool))]
        [SwaggerResponse((int)StatusCodes.Status400BadRequest)]
        [SwaggerResponse((int)StatusCodes.Status401Unauthorized)]
        [SwaggerResponse((int)StatusCodes.Status403Forbidden)]
        [HttpPost("ComBeneficiario")]
        public async Task<IActionResult> ComBeneficiario(SeloDto selo)
        {
            return StatusCode(StatusCodes.Status200OK, true);
        }

        /// <summary>
        /// Requisição novos selos
        /// </summary>
        /// <param name="pedido"></param>
        /// <returns></returns>
        /// <response code="200">Requisição realizada com sucesso</response>
        /// <response code="400">Falha interna</response>
        /// <response code="401">Token inválido</response>
        /// <response code="403">Token Expirado</response>
        [SwaggerResponse((int)StatusCodes.Status200OK, Type = typeof(bool))]
        [SwaggerResponse((int)StatusCodes.Status400BadRequest)]
        [SwaggerResponse((int)StatusCodes.Status401Unauthorized)]
        [SwaggerResponse((int)StatusCodes.Status403Forbidden)]
        [HttpPost("Pedido")]
        public async Task<IActionResult> Pedido(SeloPedidoDto pedido)
        {

            var numeroPedido = await _seloService.CadastrarPedido(pedido);

            return StatusCode(StatusCodes.Status200OK, true);
        }

        /// <summary>
        /// Estravio do Pedido
        /// </summary>
        /// <param name="pedido"></param>
        /// <returns></returns>
        /// <response code="200">Requisição realizada com sucesso</response>
        /// <response code="400">Falha interna</response>
        /// <response code="401">Token inválido</response>
        /// <response code="403">Token Expirado</response>
        [SwaggerResponse((int)StatusCodes.Status200OK, Type = typeof(bool))]
        [SwaggerResponse((int)StatusCodes.Status400BadRequest)]
        [SwaggerResponse((int)StatusCodes.Status401Unauthorized)]
        [SwaggerResponse((int)StatusCodes.Status403Forbidden)]
        [HttpPost("Pedido/Estravio")]
        public async Task<IActionResult> PedidoEstraviado(SeloPedidoEstravioDto pedido)
        {
            return StatusCode(StatusCodes.Status200OK, true);
        }

        /// <summary>
        /// Estado Atual do Pedido
        /// </summary>
        /// <param name="idpedido"></param>
        /// <returns></returns>
        /// <response code="200">Estado Atual do Pedido dos Selos</response>
        /// <response code="400">Falha interna</response>
        /// <response code="401">Token inválido</response>
        /// <response code="403">Token Expirado</response>
        [SwaggerResponse((int)StatusCodes.Status200OK, Type = typeof(SeloDto))]
        [SwaggerResponse((int)StatusCodes.Status400BadRequest)]
        [SwaggerResponse((int)StatusCodes.Status401Unauthorized)]
        [SwaggerResponse((int)StatusCodes.Status403Forbidden)]
        [HttpGet("Pedido/Estado")]
        public async Task<IActionResult> PedidoEstado(SeloDto idpedido)
        {
            return StatusCode(StatusCodes.Status200OK, true);
        }

    }
}
