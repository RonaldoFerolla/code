﻿using System.Threading.Tasks;
using TGS.ValeGas.Domain.Entidades;

namespace TGS.ValeGas.Repository.Interfaces
{
    public interface ISeloRepository
    {
        Task<NumeracaoSelos> Consultar(string selo);
    }
}
