﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TGS.ValeGas.Domain.Entidades;

namespace TGS.ValeGas.Repository.Interfaces
{
    public interface IFornecedorRepository
    {
        Task<IReadOnlyList<FornecedoresSelos>> ConsultaTodos();
        Task<FornecedoresSelos> ConsultarPorCNPJ(string cnpj);
        Task<FornecedoresSelos> ConsultarPorCNPJEstado(string cnpj);
        Task<FornecedoresSelos> ConsultarPorId(int id);
        Task Alterar(FornecedoresSelos entidade);
        Task<bool> Excluir(string cnpj);
        Task<bool> Cadastrar(FornecedoresSelos entidade);
    }
}
