﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TGS.ValeGas.Domain.Entidades;

namespace TGS.ValeGas.Repository.Interfaces
{
   public interface IBeneficiarioRepository
    {
        Task<IReadOnlyList<Beneficiarios>> ConsultaTodos();
        Task<Beneficiarios> ConsultarPorNIS(string nis);
        Task<Beneficiarios> ConsultarPorCPF(string cpf);
        Task<Beneficiarios> ConsultarPorID(long Id);
        Task Cadastrar(Beneficiarios entidade);
        Task Alterar(Beneficiarios entidade);
        Task Deletar(Beneficiarios entidade);
    }
}
