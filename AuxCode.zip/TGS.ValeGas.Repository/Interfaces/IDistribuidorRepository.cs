﻿using System.Collections.Generic;
using System.Threading.Tasks;
using TGS.ValeGas.Domain.Entidades;

namespace TGS.ValeGas.Repository.Interfaces
{
    public interface IDistribuidorRepository
    {
        Task<IReadOnlyList<Distribuidores>> ConsultaTodos();
        Task<Distribuidores> ConsultarPorCNPJ(string cnpj);
        Task<Distribuidores> ConsultarPorCNPJEstado(string cnpj);
        Task<Distribuidores> ConsultarPorId(int id);
        Task Alterar(Distribuidores entidade);
        Task<bool> Excluir(string cnpj);
        Task<bool> Cadastrar(Distribuidores entidade);
    }
}
