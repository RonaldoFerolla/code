﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TGS.ValeGas.Repository.Interfaces
{
    public interface IRelatorioRepository
    {
    }
}
