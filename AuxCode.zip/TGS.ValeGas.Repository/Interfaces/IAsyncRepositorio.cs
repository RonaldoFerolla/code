﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace TGS.ValeGas.Repository.Interfaces
{
    public interface IAsyncRepositorio<T> where T : class
    {
        Task<T> ConsultarAsync(object key);
        Task<T> ConsultarAsync(Expression<Func<T, bool>> criteria, params Expression<Func<T, object>>[] includes);
        Task<TResult> ConsultarAsync<TResult>(Expression<Func<T, TResult>> selector, Expression<Func<T, bool>> criteria = null, params Expression<Func<T, object>>[] includes);
        //Task<T> ConsultarAsync(ISpecification<T> spec);
        Task<IReadOnlyList<T>> ConsultarTodosAsync();
        Task<IReadOnlyList<TResult>> ConsultarTodosAsync<TResult>(Expression<Func<T, TResult>> selector, params Expression<Func<T, object>>[] includes);
        Task<IReadOnlyList<T>> ConsultarTodosAsync(params Expression<Func<T, object>>[] includes);
        //Task<IReadOnlyList<T>> ConsultarListaAsync(ISpecification<T> spec);
        Task<IReadOnlyList<T>> ConsultarListaAsync(Expression<Func<T, bool>> criteria, params Expression<Func<T, object>>[] includes);
        //Task<IReadOnlyList<TResult>> ConsultarListaAsync<TResult>(Expression<Func<T, TResult>> selector, ISpecification<T> spec);
        Task<T> AdicionarAsync(T entity);
        Task AtualizarAsync(T entity);
        Task ExcluirAsync(T entity);
        Task ExcluirAsync(object key);
        //Task<int> ContarAsync(ISpecification<T> spec);
        Task<bool> ExisteAsync(Expression<Func<T, bool>> criteria);
    }
}
