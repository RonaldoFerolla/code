﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;
using TGS.ValeGas.Domain.Entidades;

namespace TGS.ValeGas.Repository.Mappings
{
    public class RevendedoresEstadosMapping : IEntityTypeConfiguration<RevendedoresEstados>
    {
        public void Configure(EntityTypeBuilder<RevendedoresEstados> entity)
        {
            entity.HasKey(e => e.IdEstado)
                    .HasName("RevendedoresEstadosPK");

            entity.ToTable("RevendedoresEstados");

            entity.Property(e => e.DataOperacao).HasColumnType("datetime");

            entity.HasOne(d => d.IdEstadoRevendedorNavigation)
                .WithMany(p => p.RevendedoresEstados)
                .HasForeignKey(d => d.IdEstadoRevendedor)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("RevendedoresEstadosEstadosRevendedoresPCFK");

            entity.HasOne(d => d.IdRevendedorNavigation)
                .WithMany(p => p.RevendedoresEstados)
                .HasForeignKey(d => d.IdRevendedor)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("RevendedoresEstadosRevendedoresFK");
        }
    }
}
