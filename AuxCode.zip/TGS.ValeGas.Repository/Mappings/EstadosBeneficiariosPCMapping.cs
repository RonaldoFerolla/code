﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using TGS.ValeGas.Domain.Entidades;

namespace TGS.ValeGas.Repository.Mappings
{
    public class EstadosBeneficiariosPCMapping : IEntityTypeConfiguration<EstadosBeneficiariosPC>
    {
        public void Configure(EntityTypeBuilder<EstadosBeneficiariosPC> entity)
        {
            entity.HasKey(e => e.IdEstadoBeneficiario)
                .HasName("EstadosBeneficiariosPCPK");

            entity.ToTable("EstadosBeneficiariosPC");

            entity.HasIndex(e => e.Descricao, "EstadosBeneficiariosPCUQ")
                .IsUnique();

            entity.Property(e => e.IdEstadoBeneficiario).ValueGeneratedNever();

            entity.Property(e => e.Descricao)
                .IsRequired()
                .HasMaxLength(100)
                .IsUnicode(false);
        }
    }
}
