﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using TGS.ValeGas.Domain.Entidades;

namespace TGS.ValeGas.Repository.Mappings
{
    public class AspNetUserClaimsMapping : IEntityTypeConfiguration<AspNetUserClaims>
    {
        public void Configure(EntityTypeBuilder<AspNetUserClaims> entity)
        {
            entity.ToTable("AspNetUserClaims");

            entity.Property(e => e.UserId)
                .IsRequired()
                .HasMaxLength(450);
        }
    }
}
