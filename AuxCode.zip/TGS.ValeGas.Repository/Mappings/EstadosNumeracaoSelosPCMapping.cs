﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using TGS.ValeGas.Domain.Entidades;

namespace TGS.ValeGas.Repository.Mappings
{
    public class EstadosNumeracaoSelosPCMapping : IEntityTypeConfiguration<EstadosNumeracaoSelosPC>
    {
        public void Configure(EntityTypeBuilder<EstadosNumeracaoSelosPC> entity)
        {
            entity.HasKey(e => e.IdEstadoSelo)
                .HasName("EstadosNumeracaoSelosPCPK");

            entity.ToTable("EstadosNumeracaoSelosPC");

            entity.HasIndex(e => e.Descricao, "EstadosNumeracaoSelosPCUQ")
                .IsUnique();

            entity.Property(e => e.IdEstadoSelo).ValueGeneratedNever();

            entity.Property(e => e.Descricao)
                .IsRequired()
                .HasMaxLength(100)
                .IsUnicode(false);
        }
    }
}
