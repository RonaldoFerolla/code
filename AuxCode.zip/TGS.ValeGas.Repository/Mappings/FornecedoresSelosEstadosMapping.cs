﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;
using TGS.ValeGas.Domain.Entidades;

namespace TGS.ValeGas.Repository.Mappings
{
    public class FornecedoresSelosEstadosMapping : IEntityTypeConfiguration<FornecedoresSelosEstados>
    {
        public void Configure(EntityTypeBuilder<FornecedoresSelosEstados> entity)
        {
            entity.HasKey(e => e.IdEstado)
    .HasName("FornecedoresSelosEstadosPK");

            entity.ToTable("FornecedoresSelosEstados");

            entity.Property(e => e.DataOperacao).HasColumnType("datetime");

            entity.HasOne(d => d.IdEstadoFornecedorSeloNavigation)
                .WithMany(p => p.FornecedoresSelosEstados)
                .HasForeignKey(d => d.IdEstadoFornecedorSelo)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FornecedoresSelosEstadosEstadosFornecedoresSelosPCFK");

            entity.HasOne(d => d.IdFornecedorSeloNavigation)
                .WithMany(p => p.FornecedoresSelosEstados)
                .HasForeignKey(d => d.IdFornecedorSelo)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FornecedoresSelosEstadosFornecedoresSelosFK");
        }
    }
}
