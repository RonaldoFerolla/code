﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;
using TGS.ValeGas.Domain.Entidades;

namespace TGS.ValeGas.Repository.Mappings
{
    public class NumeracaoSelosBeneficiariosEstadosMapping : IEntityTypeConfiguration<NumeracaoSelosBeneficiariosEstados>
    {
        public void Configure(EntityTypeBuilder<NumeracaoSelosBeneficiariosEstados> entity)
        {
            entity.HasKey(e => e.IdEstado)
                    .HasName("NumeracaoSelosBeneficiariosEstadosPK");

            entity.ToTable("NumeracaoSelosBeneficiariosEstados");

            entity.HasIndex(e => new { e.IdNumeracaoSeloBeneficiario, e.IdEstadoNumeracaoSeloBeneficiario, e.DataOperacao }, "NumeracaoSelosBeneficiariosEstadosUQ")
                .IsUnique();

            entity.Property(e => e.DataOperacao).HasColumnType("datetime");

            entity.HasOne(d => d.IdEstadoNumeracaoSeloBeneficiarioNavigation)
                .WithMany(p => p.NumeracaoSelosBeneficiariosEstados)
                .HasForeignKey(d => d.IdEstadoNumeracaoSeloBeneficiario)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("NumeracaoSelosBeneficiariosEstadosEstadosNumeracaoSelosBeneficiariosPCFK");

            entity.HasOne(d => d.IdNumeracaoSeloBeneficiarioNavigation)
                .WithMany(p => p.NumeracaoSelosBeneficiariosEstados)
                .HasForeignKey(d => d.IdNumeracaoSeloBeneficiario)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("NumeracaoSelosBeneficiariosEstadosNumeracaoSelosBeneficiariosFK");
        }
    }
}
