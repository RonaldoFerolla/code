﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using TGS.ValeGas.Domain.Entidades;

namespace TGS.ValeGas.Repository.Mappings
{
    public class FornecedoresSelosMapping : IEntityTypeConfiguration<FornecedoresSelos>
    {
        public void Configure(EntityTypeBuilder<FornecedoresSelos> entity)
        {
            entity.HasKey(e => e.IdFornecedorSelo)
                .HasName("FornecedoresSelosPK");

            entity.ToTable("FornecedoresSelos");

            entity.Property(e => e.DataOperacao).HasColumnType("datetime");

            entity.HasOne(d => d.IdEstadoFornecedorSeloNavigation)
                .WithMany(p => p.FornecedoresSelos)
                .HasForeignKey(d => d.IdEstadoFornecedorSelo)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FornecedoresSelosEstadosFornecedoresSelosPCFK");

            entity.HasOne(d => d.IdUsuarioNavigation)
                .WithMany(p => p.FornecedoresSelos)
                .HasForeignKey(d => d.IdUsuario)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FornecedoresSelosUsuariosFK");
        }
    }
}
