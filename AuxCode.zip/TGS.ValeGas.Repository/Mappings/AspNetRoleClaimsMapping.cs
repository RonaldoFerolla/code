﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;
using TGS.ValeGas.Domain.Entidades;

namespace TGS.ValeGas.Repository.Mappings
{
    public class AspNetRoleClaimsMapping : IEntityTypeConfiguration<AspNetRoleClaims>
    {
        public void Configure(EntityTypeBuilder<AspNetRoleClaims> entity)
        {
            entity.ToTable("AspNetRoleClaims");

            entity.Property(e => e.RoleId)
                .IsRequired()
                .HasMaxLength(450);
        }
    }
}
