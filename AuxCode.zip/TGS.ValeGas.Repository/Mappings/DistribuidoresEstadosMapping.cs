﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;
using TGS.ValeGas.Domain.Entidades;

namespace TGS.ValeGas.Repository.Mappings
{
    public class DistribuidoresEstadosMapping : IEntityTypeConfiguration<DistribuidoresEstados>
    {
        public void Configure(EntityTypeBuilder<DistribuidoresEstados> entity)
        {
            entity.HasKey(e => e.IdEstado)
                    .HasName("DistribuidoresEstadosPK");

            entity.ToTable("DistribuidoresEstados");

            entity.Property(e => e.DataOperacao).HasColumnType("datetime");

            entity.HasOne(d => d.IdDistribuidorNavigation)
                .WithMany(p => p.DistribuidoresEstados)
                .HasForeignKey(d => d.IdDistribuidor)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("DistribuidoresEstadosDistribuidoresFK");

            entity.HasOne(d => d.IdEstadoDistribuidorNavigation)
                .WithMany(p => p.DistribuidoresEstados)
                .HasForeignKey(d => d.IdEstadoDistribuidor)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("DistribuidoresEstadosEstadosDistribuidoresPCFK");
        }
    }
}
