﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using TGS.ValeGas.Domain.Entidades;

namespace TGS.ValeGas.Repository.Mappings
{
    public class BeneficiariosMapping : IEntityTypeConfiguration<Beneficiarios>
    {
        public void Configure(EntityTypeBuilder<Beneficiarios> entity)
        {
            entity.HasKey(e => e.IdBeneficiario)
                               .HasName("BeneficiariosPK");

            entity.ToTable("Beneficiarios");

            entity.HasIndex(e => e.NuDocumento, "BeneficiariosUQ")
                .IsUnique();

            entity.Property(e => e.NomeBeneficiario).HasColumnType("string");

            entity.HasOne(d => d.IdEstadoBeneficiarioNavigation)
                .WithMany(p => p.Beneficiarios)
                .HasForeignKey(d => d.IdEstadoBeneficiario)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("BeneficiariosEstadosBeneficiariosPCFK");

            entity.HasOne(d => d.IdUsuarioNavigation)
                .WithMany(p => p.Beneficiarios)
                .HasForeignKey(d => d.IdUsuario)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("BeneficiariosUsuariosFK");
        }
    }
}
