﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using TGS.ValeGas.Domain.Entidades;

namespace TGS.ValeGas.Repository.Mappings
{
    public class DistribuidoresMapping : IEntityTypeConfiguration<Distribuidores>
    {
        public void Configure(EntityTypeBuilder<Distribuidores> entity)
        {
            entity.HasKey(e => e.IdDistribuidor)
                   .HasName("DistribuidoresPK");

            entity.ToTable("Distribuidores");

            entity.Property(e => e.DataOperacao).HasColumnType("datetime");

            entity.Property(e => e.NomeDistribuidor)
                .HasMaxLength(200)
                .IsUnicode(false);

            entity.HasOne(d => d.IdEstadoDistribuidorNavigation)
                .WithMany(p => p.Distribuidores)
                .HasForeignKey(d => d.IdEstadoDistribuidor)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("DistribuidoresEstadosDistribuidoresPCFK");

            entity.HasOne(d => d.IdUsuarioNavigation)
                .WithMany(p => p.Distribuidores)
                .HasForeignKey(d => d.IdUsuario)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("DistribuidoresUsuariosFK");
        }
    }
}
