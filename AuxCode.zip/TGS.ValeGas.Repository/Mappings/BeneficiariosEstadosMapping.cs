﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;
using TGS.ValeGas.Domain.Entidades;

namespace TGS.ValeGas.Repository.Mappings
{
    public class BeneficiariosEstadosMapping : IEntityTypeConfiguration<BeneficiariosEstados>
    {
        public void Configure(EntityTypeBuilder<BeneficiariosEstados> entity)
        {
            entity.HasKey(e => e.IdEstado)
                  .HasName("BeneficiariosEstadosPK");

            entity.ToTable("BeneficiariosEstados");

            entity.HasIndex(e => new { e.IdBeneficiario, e.IdEstadoBeneficiario, e.DataOperacao }, "BeneficiariosEstadosUQ")
                .IsUnique();

            entity.Property(e => e.DataOperacao).HasColumnType("datetime");

            entity.HasOne(d => d.IdBeneficiarioNavigation)
                .WithMany(p => p.BeneficiariosEstados)
                .HasForeignKey(d => d.IdBeneficiario)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("BeneficiariosEstadosBeneficiariosFK");

            entity.HasOne(d => d.IdEstadoBeneficiarioNavigation)
                .WithMany(p => p.BeneficiariosEstados)
                .HasForeignKey(d => d.IdEstadoBeneficiario)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("BeneficiariosEstadosEstadosBeneficiariosPCFK");
        }
    }
}
