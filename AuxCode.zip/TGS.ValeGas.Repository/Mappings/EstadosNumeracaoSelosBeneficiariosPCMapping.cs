﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using TGS.ValeGas.Domain.Entidades;

namespace TGS.ValeGas.Repository.Mappings
{
    public class EstadosNumeracaoSelosBeneficiariosPCMapping : IEntityTypeConfiguration<EstadosNumeracaoSelosBeneficiariosPC>
    {
        public void Configure(EntityTypeBuilder<EstadosNumeracaoSelosBeneficiariosPC> entity)
        {
            entity.HasKey(e => e.IdEstadoNumeracaoSeloBeneficiario)
                .HasName("EstadosNumeracaoSelosBeneficiariosPCPK");

            entity.ToTable("EstadosNumeracaoSelosBeneficiariosPC");

            entity.HasIndex(e => e.Descricao, "EstadosNumeracaoSelosBeneficiariosPCUQ")
                .IsUnique();

            entity.Property(e => e.IdEstadoNumeracaoSeloBeneficiario).ValueGeneratedNever();

            entity.Property(e => e.Descricao)
                .IsRequired()
                .HasMaxLength(100)
                .IsUnicode(false);
        }
    }
}
