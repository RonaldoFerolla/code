﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using TGS.ValeGas.Domain.Entidades;

namespace TGS.ValeGas.Repository.Mappings
{
    public class NumeracaoSelosMapping : IEntityTypeConfiguration<NumeracaoSelos>
    {
        public void Configure(EntityTypeBuilder<NumeracaoSelos> entity)
        {
            entity.HasKey(e => e.IdNumeroSelo)
                     .HasName("NumeracaoSelosPK");

            entity.ToTable("NumeracaoSelos");

            entity.HasIndex(e => e.Selo, "NumeracaoSelosUQ")
                .IsUnique();

            entity.Property(e => e.DataOperacao).HasColumnType("datetime");

            entity.Property(e => e.Selo)
                .IsRequired()
                .HasMaxLength(30)
                .IsUnicode(false);

            entity.HasOne(d => d.IdDistribuidorNavigation)
                .WithMany(p => p.NumeracaoSelos)
                .HasForeignKey(d => d.IdDistribuidor)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("NumeracaoSelosDistribuidoresFK");

            entity.HasOne(d => d.IdEstadoSeloNavigation)
                .WithMany(p => p.NumeracaoSelos)
                .HasForeignKey(d => d.IdEstadoSelo)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("NumeracaoSelosEstadosNumeracaoSelosPCFK");

            entity.HasOne(d => d.IdRevendedorNavigation)
                .WithMany(p => p.NumeracaoSelos)
                .HasForeignKey(d => d.IdRevendedor)
                .HasConstraintName("NumeracaoSelosRevendedoresFK");

            entity.HasOne(d => d.IdUsuarioNavigation)
                .WithMany(p => p.NumeracaoSelos)
                .HasForeignKey(d => d.IdUsuario)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("NumeracaoSelosUsuariosFK");
        }
    }
}
