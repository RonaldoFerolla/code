﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;
using TGS.ValeGas.Domain.Entidades;

namespace TGS.ValeGas.Repository.Mappings
{
    public class NumeracaoSelosEstadosMapping : IEntityTypeConfiguration<NumeracaoSelosEstados>
    {
        public void Configure(EntityTypeBuilder<NumeracaoSelosEstados> entity)
        {
            entity.HasKey(e => e.IdNumeroSelo)
                    .HasName("NumeracaoSelosEstadosPK");

            entity.ToTable("NumeracaoSelosEstados");

            entity.Property(e => e.IdNumeroSelo).ValueGeneratedNever();

            entity.Property(e => e.DataOperacao).HasColumnType("datetime");

            entity.Property(e => e.IdEstados).ValueGeneratedOnAdd();

            entity.HasOne(d => d.IdEstadoSeloNavigation)
                .WithMany(p => p.NumeracaoSelosEstados)
                .HasForeignKey(d => d.IdEstadoSelo)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("NumeracaoSelosEstadosEstadosNumeracaoSelosPCFK");

            entity.HasOne(d => d.IdNumeroSeloNavigation)
                .WithOne(p => p.NumeracaoSelosEstados)
                .HasForeignKey<NumeracaoSelosEstados>(d => d.IdNumeroSelo)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("NumeracaoSelosEstadosNumeracaoSelosFK");
        }
    }
}
