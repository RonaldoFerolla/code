﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using TGS.ValeGas.Domain.Entidades;

namespace TGS.ValeGas.Repository.Mappings
{
    public class LogSistemaMapping : IEntityTypeConfiguration<LogSistema>
    {
        public void Configure(EntityTypeBuilder<LogSistema> entity)
        {
            entity.HasKey(e => e.IdLogSistema)
                .HasName("LogSistemaPK");

            entity.ToTable("LogSistema");

            entity.Property(e => e.CodLogSistema)
                .IsRequired()
                .HasMaxLength(50)
                .IsUnicode(false);

            entity.Property(e => e.DataOperacao).HasColumnType("datetime");

            entity.Property(e => e.JsonConteudo).IsRequired();
        }
    }
}
