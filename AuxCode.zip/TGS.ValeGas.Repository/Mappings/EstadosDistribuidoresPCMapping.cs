﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using TGS.ValeGas.Domain.Entidades;

namespace TGS.ValeGas.Repository.Mappings
{
    class EstadosDistribuidoresPCMapping : IEntityTypeConfiguration<EstadosDistribuidoresPC>
    {
        public void Configure(EntityTypeBuilder<EstadosDistribuidoresPC> entity)
        {
            entity.HasKey(e => e.IdEstadoDistribuidor)
                .HasName("EstadosDistribuidoresPCPK");

            entity.ToTable("EstadosDistribuidoresPC");

            entity.HasIndex(e => e.Descricao, "EstadosDistribuidoresPCUQ")
                .IsUnique();

            entity.Property(e => e.IdEstadoDistribuidor).ValueGeneratedNever();

            entity.Property(e => e.Descricao)
                .HasMaxLength(100)
                .IsUnicode(false);
        }
    }
}
