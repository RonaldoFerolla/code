﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using TGS.ValeGas.Domain.Entidades;

namespace TGS.ValeGas.Repository.Mappings
{
    public class NumeracaoSelosBeneficiariosMapping : IEntityTypeConfiguration<NumeracaoSelosBeneficiarios>
    {
        public void Configure(EntityTypeBuilder<NumeracaoSelosBeneficiarios> entity)
        {
            entity.HasKey(e => e.IdNumeracaoSeloBeneficiario)
                   .HasName("NumeracaoSelosBeneficiariosPK");

            entity.ToTable("NumeracaoSelosBeneficiarios");

            entity.Property(e => e.DataOperacao).HasColumnType("datetime");

            entity.HasOne(d => d.IdBeneficiarioNavigation)
                .WithMany(p => p.NumeracaoSelosBeneficiarios)
                .HasForeignKey(d => d.IdBeneficiario)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("NumeracaoSelosBeneficiariosBeneficiariosFK");

            entity.HasOne(d => d.IdEstadoNumeracaoSeloBeneficiarioNavigation)
                .WithMany(p => p.NumeracaoSelosBeneficiarios)
                .HasForeignKey(d => d.IdEstadoNumeracaoSeloBeneficiario)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("NumeracaoSelosBeneficiariosEstadosNumeracaoSelosBeneficiariosPCFK");

            entity.HasOne(d => d.IdNumeroSeloNavigation)
                .WithMany(p => p.NumeracaoSelosBeneficiarios)
                .HasForeignKey(d => d.IdNumeroSelo)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("NumeracaoSelosBeneficiariosNumeracaoSelosFK");

            entity.HasOne(d => d.IdUsuarioNavigation)
                .WithMany(p => p.NumeracaoSelosBeneficiarios)
                .HasForeignKey(d => d.IdUsuario)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("NumeracaoSelosBeneficiariosUsuariosFK");
        }
    }
}
