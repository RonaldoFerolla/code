﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using TGS.ValeGas.Domain.Entidades;

namespace TGS.ValeGas.Repository.Mappings
{
    public class RevendedoresMapping : IEntityTypeConfiguration<Revendedores>
    {
        public void Configure(EntityTypeBuilder<Revendedores> entity)
        {
            entity.HasKey(e => e.IdRevendedor)
                    .HasName("RevendedoresPK");

            entity.ToTable("Revendedores");

            entity.Property(e => e.DataOperacao).HasColumnType("datetime");

            entity.Property(e => e.NomeRevendedor)
                .HasMaxLength(200)
                .IsUnicode(false);

            entity.HasOne(d => d.IdEstadoRevendedorNavigation)
                .WithMany(p => p.Revendedores)
                .HasForeignKey(d => d.IdEstadoRevendedor)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("RevendedoresEstadosRevendedoresPCFK");

            entity.HasOne(d => d.IdUsuarioNavigation)
                .WithMany(p => p.Revendedores)
                .HasForeignKey(d => d.IdUsuario)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("RevendedoresUsuariosFK");
        }
    }
}
