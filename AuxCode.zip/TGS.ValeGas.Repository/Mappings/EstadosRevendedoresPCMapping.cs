﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;
using TGS.ValeGas.Domain.Entidades;

namespace TGS.ValeGas.Repository.Mappings
{
    public class EstadosRevendedoresPCMapping : IEntityTypeConfiguration<EstadosRevendedoresPC>
    {
        public void Configure(EntityTypeBuilder<EstadosRevendedoresPC> entity)
        {
            entity.HasKey(e => e.IdEstadoRevendedor)
                   .HasName("EstadosRevendedoresPCPK");

            entity.ToTable("EstadosRevendedoresPC");

            entity.HasIndex(e => e.Descricao, "EstadosRevendedoresPCUQ")
                .IsUnique();

            entity.Property(e => e.IdEstadoRevendedor).ValueGeneratedNever();

            entity.Property(e => e.Descricao)
                .HasMaxLength(100)
                .IsUnicode(false);
        }
    }
}
