﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using TGS.ValeGas.Domain.Entidades;

namespace TGS.ValeGas.Repository.Mappings
{
    public class EstadosFornecedoresSelosPCMapping : IEntityTypeConfiguration<EstadosFornecedoresSelosPC>
    {
        public void Configure(EntityTypeBuilder<EstadosFornecedoresSelosPC> entity)
        {
            entity.HasKey(e => e.IdEstadoFornecedorSelo)
                .HasName("EstadosFornecedoresSelosPCPK");

            entity.ToTable("EstadosFornecedoresSelosPC");

            entity.HasIndex(e => e.Descricao, "EstadosFornecedoresSelosPCUQ")
                .IsUnique();

            entity.Property(e => e.IdEstadoFornecedorSelo).ValueGeneratedNever();

            entity.Property(e => e.Descricao)
                .IsRequired()
                .HasMaxLength(100)
                .IsUnicode(false);
        }
    }
}
