﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using TGS.ValeGas.Domain.Entidades;

namespace TGS.ValeGas.Repository.Mappings
{
    public class UsuariosMapping : IEntityTypeConfiguration<Usuarios>
    {
        public void Configure(EntityTypeBuilder<Usuarios> entity)
        {
            entity.HasKey(e => e.IdUsuario)
                   .HasName("UsuariosPK");

            entity.ToTable("Usuarios");

            entity.HasIndex(e => e.Email, "UsuariosUK")
                .IsUnique();

            entity.HasIndex(e => e.IdUsuarioIdentity, "UsuariosUQ")
                .IsUnique();

            entity.Property(e => e.DataOperacao).HasColumnType("datetime");

            entity.Property(e => e.Email)
                .IsRequired()
                .HasMaxLength(100)
                .IsUnicode(false);

            entity.Property(e => e.NomeUsuario)
                .IsRequired()
                .HasMaxLength(100)
                .IsUnicode(false);

            entity.HasOne(d => d.IdUsuarioIdentityNavigation)
                .WithOne(p => p.Usuarios)
                .HasForeignKey<Usuarios>(d => d.IdUsuarioIdentity)
                .HasConstraintName("UsuariosAspNetUsersFK");
        }
    }
}
