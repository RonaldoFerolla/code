﻿using Dapper;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using TGS.ValeGas.Domain.Entidades;
using TGS.ValeGas.Infra.DTOs.Distribuidor;
using TGS.ValeGas.Repository.Contexto;
using TGS.ValeGas.Repository.Interfaces;

namespace TGS.ValeGas.Repository.Entidades
{
    public class DistribuidorRepository : BaseRepositorio<Distribuidores>, IDistribuidorRepository
    {
        private readonly IAsyncRepositorio<Distribuidores> _distribuidores;

        public DistribuidorRepository(IAsyncRepositorio<Distribuidores> distribuidores, EFContexto dbContext) : base(dbContext)
        {
            _distribuidores = distribuidores;
        }

        public async Task<Distribuidores> ConsultarPorId(int id)
        {
            return await _distribuidores.ConsultarAsync(x => x.IdDistribuidor == id);
        }

        public async Task<Distribuidores> ConsultarPorCNPJ(string cnpj)
        {
            return await _distribuidores.ConsultarAsync(x => x.NuDocumento == long.Parse(cnpj));
        }

        public async Task<IReadOnlyList<Distribuidores>> ConsultaTodos()
        {
            return await _distribuidores.ConsultarTodosAsync();
        }

        public async Task<Distribuidores> ConsultarPorCNPJEstado(string cnpj)
        {
            return await _distribuidores.ConsultarAsync(x => x.NuDocumento == long.Parse(cnpj), x => x.IdEstadoDistribuidorNavigation);
        }

        public async Task Alterar(Distribuidores entidade)
        {
            var parametros = new DynamicParameters();
            parametros.Add("@NuDocumento", entidade.NuDocumento);
            parametros.Add("@NomeDistribuidor", entidade.NomeDistribuidor);
            parametros.Add("@CamposExtras", entidade.CamposExtras);
            parametros.Add("@IdUsuario", 0); // Fixo 0 para utilizar id do administrador

            var conexao = _dbContext.Database.GetDbConnection();

            CommandDefinition command = new CommandDefinition("SpAtualizarDistribuidor", parametros, commandType: CommandType.StoredProcedure);
            await conexao.ExecuteAsync(command);

            //await _distribuidores.AtualizarAsync(entidade);
        }

        public async Task<bool> Excluir(string cnpj)
        {
            var parametros = new DynamicParameters();
            parametros.Add("@NuDocumento", cnpj);
            parametros.Add("@IdUsuario", 0); // Fixo 0 para utilizar id do administrador

            var conexao = _dbContext.Database.GetDbConnection();

            CommandDefinition command = new CommandDefinition("SpInativarDistribuidor", parametros, commandType: CommandType.StoredProcedure);
            await conexao.ExecuteAsync(command);
            return true;
        }

        public async Task<bool> Cadastrar(Distribuidores entidade)
        {
           var distribuidor =  await _distribuidores.AdicionarAsync(entidade);
            return distribuidor.IdDistribuidor > 0;
        }


        public async Task ExemploSP()
        {
            var parametros = new DynamicParameters();
            parametros.Add("@Id", 1);

            var conexao = _dbContext.Database.GetDbConnection();

            CommandDefinition command = new CommandDefinition("Sp", parametros, commandType: CommandType.StoredProcedure);
            await conexao.ExecuteAsync(command);
        }

        
    }
}
