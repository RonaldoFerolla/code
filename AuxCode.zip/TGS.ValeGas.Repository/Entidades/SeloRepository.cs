﻿using Dapper;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Threading.Tasks;
using TGS.ValeGas.Domain.Entidades;
using TGS.ValeGas.Repository.Contexto;
using TGS.ValeGas.Repository.Interfaces;

namespace TGS.ValeGas.Repository.Entidades
{
    public class SeloRepository : BaseRepositorio<NumeracaoSelos>, ISeloRepository
    {
        private readonly IAsyncRepositorio<NumeracaoSelos> _selos;

        public SeloRepository(IAsyncRepositorio<NumeracaoSelos> selos, EFContexto dbContext) : base(dbContext)
        {
            _selos = selos;
        }

        public async Task<NumeracaoSelos> Consultar(string selo)
        {
            return await _selos.ConsultarAsync(x => x.Selo == selo);
        }
        public async Task ExemploSP()
        {
            var parametros = new DynamicParameters();
            parametros.Add("@Id", 1);

            var conexao = _dbContext.Database.GetDbConnection();

            CommandDefinition command = new CommandDefinition("Sp", parametros, commandType: CommandType.StoredProcedure);
            await conexao.ExecuteAsync(command);
        }
    }
}
