﻿using Dapper;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Data;
using System;
using System.Threading.Tasks;
using TGS.ValeGas.Domain.Entidades;
using TGS.ValeGas.Infra.DTOs.Fornecedor;
using TGS.ValeGas.Repository.Contexto;
using TGS.ValeGas.Repository.Interfaces;

namespace TGS.ValeGas.Repository.Entidades
{
    public class FornecedorRepository : BaseRepositorio<FornecedoresSelos>, IFornecedorRepository
    {
        private readonly IAsyncRepositorio<FornecedoresSelos> _fornecedores;

        public FornecedorRepository(IAsyncRepositorio<FornecedoresSelos> fornecedores, EFContexto dbContext) : base(dbContext)
        {
            _fornecedores = fornecedores;
        }

        public async Task<FornecedoresSelos> ConsultarPorId(int id)
        {
            return await _fornecedores.ConsultarAsync(x => x.IdFornecedorSelo == id);
        }

        public async Task<FornecedoresSelos> ConsultarPorCNPJ(string cnpj)
        {
            return await _fornecedores.ConsultarAsync(x => x.NuDocumento == long.Parse(cnpj));
        }

        public async Task<IReadOnlyList<FornecedoresSelos>> ConsultaTodos()
        {
            return await _fornecedores.ConsultarTodosAsync();
        }

        public async Task<FornecedoresSelos> ConsultarPorCNPJEstado(string cnpj)
        {
            return await _fornecedores.ConsultarAsync(x => x.NuDocumento == long.Parse(cnpj), x => x.IdEstadoFornecedorSeloNavigation);
        }

        public async Task Alterar(FornecedoresSelos entidade)
        {
            var parametros = new DynamicParameters();
            parametros.Add("@NuDocumento", entidade.NuDocumento);
            parametros.Add("@CamposExtras", entidade.CamposExtras);
            parametros.Add("@NomeFornecedor", entidade.NomeFornecedor);
            parametros.Add("@IdUsuario", 0); // Fixo 0 para utilizar id do administrador

            var conexao = _dbContext.Database.GetDbConnection();

            CommandDefinition command = new CommandDefinition("SpAtualizarFornecedorSelo", parametros, commandType: CommandType.StoredProcedure);
            
            try
            {
                await conexao.ExecuteAsync(command);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public async Task<bool> Excluir(string cnpj)
        {
            var parametros = new DynamicParameters();
            parametros.Add("@NuDocumento", cnpj);
            parametros.Add("@IdUsuario", 0); // Fixo 0 para utilizar id do administrador

            var conexao = _dbContext.Database.GetDbConnection();

            CommandDefinition command = new CommandDefinition("SpInativaFornecedorSelo", parametros, commandType: CommandType.StoredProcedure);
            
            try
            {
                await conexao.ExecuteAsync(command);
                return true;
            }
            catch
            {
                return false;
            } 
        }

        public async Task<bool> Cadastrar(FornecedoresSelos entidade)
        {
            var fornecedores = await _fornecedores.AdicionarAsync(entidade);
            return fornecedores.IdFornecedorSelo > 0;
        }
    }
}
