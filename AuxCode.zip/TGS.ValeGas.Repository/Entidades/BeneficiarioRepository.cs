﻿using Dapper;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;
using TGS.ValeGas.Domain.Entidades;
using TGS.ValeGas.Repository.Contexto;
using TGS.ValeGas.Repository.Interfaces;


namespace TGS.ValeGas.Repository.Entidades
{
    public  class BeneficiarioRepository : BaseRepositorio<Beneficiarios>, IBeneficiarioRepository 
    {

        private readonly IAsyncRepositorio<Beneficiarios> _beneficiarios;

        public BeneficiarioRepository(IAsyncRepositorio<Beneficiarios> beneficiarios, EFContexto dbContext) : base(dbContext)
        {
            _beneficiarios = beneficiarios;
        }

        public async Task Cadastrar(Beneficiarios entidade)
        {
            await _beneficiarios.AdicionarAsync(entidade);
        }

        public async Task Alterar(Beneficiarios entidade)
        {
             var p = new DynamicParameters();
            p.Add("@NuDocumento", entidade.NuDocumento);
            p.Add("@NomeBeneficiario", entidade.NomeBeneficiario);
            p.Add("@CamposExtras", entidade.CamposExtras);
            p.Add("@IdUsuario", entidade.IdUsuario);
 
            var conexao = _dbContext.Database.GetDbConnection();
            CommandDefinition command = new CommandDefinition("SpAtualizarBeneficiario", p, commandType: CommandType.StoredProcedure);

            try
            {
                var retorno = await conexao.ExecuteScalarAsync(command);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task Deletar(Beneficiarios entidade)
        {
            var p = new DynamicParameters();
            p.Add("@NuDocumento", entidade.NuDocumento);
            p.Add("@IdUsuario", entidade.IdUsuario);

            var conexao = _dbContext.Database.GetDbConnection();
            CommandDefinition command = new CommandDefinition("SpInativarBeneficiario", p, commandType: CommandType.StoredProcedure);

            try
            {
                var retorno = await conexao.ExecuteScalarAsync(command);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IReadOnlyList<Beneficiarios>> ConsultaTodos()
        {
            return await _beneficiarios.ConsultarTodosAsync();
        }

        public async Task<Beneficiarios> ConsultarPorNIS(string nis)
        {
            return await _beneficiarios.ConsultarAsync(x => x.NuDocumento == long.Parse(nis));
        }

        public async Task<Beneficiarios> ConsultarPorCPF(string cpf)
        {
            return await _beneficiarios.ConsultarAsync(x => x.NuDocumento == long.Parse(cpf));
        }

        public async Task<Beneficiarios> ConsultarPorID(long Id)
        {
            return await _beneficiarios.ConsultarAsync(x => x.IdBeneficiario == Id);
        }

        public async Task ExemploSP()
        {
            var parametros = new DynamicParameters();
            parametros.Add("@Id", 1);

            var conexao = _dbContext.Database.GetDbConnection();

            CommandDefinition command = new CommandDefinition("Sp", parametros, commandType: CommandType.StoredProcedure);
            await conexao.ExecuteAsync(command);
        }

    }
}
