﻿using System;
using System.Collections.Generic;
using System.Text;
using TGS.ValeGas.Repository.Interfaces;

namespace TGS.ValeGas.Repository.Entidades
{
    public class PagamentoRepository : IPagamentoRepository
    {
    }
}
