﻿using TGS.ValeGas.Repository.Interfaces;

namespace TGS.ValeGas.Repository.Entidades
{
    public class RelatorioRepository : IRelatorioRepository
    {
    }
}
