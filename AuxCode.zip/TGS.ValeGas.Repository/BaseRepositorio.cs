﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;
using TGS.ValeGas.Repository.Contexto;
using TGS.ValeGas.Repository.Interfaces;

namespace TGS.ValeGas.Repository
{
    public class BaseRepositorio<T> : IAsyncRepositorio<T> where T : class
    {
        protected readonly EFContexto _dbContext;
        public BaseRepositorio(EFContexto dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<T> AdicionarAsync(T entity)
        {
            try
            {
                _dbContext.Set<T>().Add(entity);
                await _dbContext.SaveChangesAsync();

                return entity;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task AtualizarAsync(T entity)
        {
            try
            {
                _dbContext.Entry(entity).State = EntityState.Modified;
                await _dbContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<T> ConsultarAsync(object key)
        {
            try
            {
                return await _dbContext.Set<T>().FindAsync(key);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<T> ConsultarAsync(Expression<Func<T, bool>> criteria, params Expression<Func<T, object>>[] includes)
        {
            try
            {
                IQueryable<T> query = _dbContext.Set<T>();

                foreach (var include in includes)
                {
                    query = query.Include(include);
                }

                return await query.FirstOrDefaultAsync(criteria);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<TResult> ConsultarAsync<TResult>(Expression<Func<T, TResult>> selector, Expression<Func<T, bool>> criteria = null, params Expression<Func<T, object>>[] includes)
        {
            try
            {
                IQueryable<T> query = _dbContext.Set<T>();

                foreach (var include in includes)
                {
                    query = query.Include(include);
                }
                return await query.Where(criteria).Select(selector).FirstOrDefaultAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IReadOnlyList<T>> ConsultarListaAsync(Expression<Func<T, bool>> criteria, params Expression<Func<T, object>>[] includes)
        {
            try
            {
                IQueryable<T> query = _dbContext.Set<T>();

                foreach (var include in includes)
                {
                    query = query.Include(include);
                }

                return await query.Where(criteria).ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IReadOnlyList<T>> ConsultarTodosAsync()
        {
            try
            {
                return await _dbContext.Set<T>().ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IReadOnlyList<TResult>> ConsultarTodosAsync<TResult>(Expression<Func<T, TResult>> selector, params Expression<Func<T, object>>[] includes)
        {
            try
            {
                IQueryable<T> query = _dbContext.Set<T>();

                foreach (var include in includes)
                {
                    query = query.Include(include);
                }
                return await query.Select(selector).ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<IReadOnlyList<T>> ConsultarTodosAsync(params Expression<Func<T, object>>[] includes)
        {
            try
            {
                IQueryable<T> query = _dbContext.Set<T>();

                foreach (var include in includes)
                {
                    query = query.Include(include);
                }

                return await query.ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task ExcluirAsync(T entity)
        {
            try
            {
                _dbContext.Set<T>().Remove(entity);
                await _dbContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task ExcluirAsync(object key)
        {
            try
            {
                var entity = await _dbContext.Set<T>().FindAsync(key);
                _dbContext.Set<T>().Remove(entity);
                await _dbContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<bool> ExisteAsync(Expression<Func<T, bool>> criteria)
        {
            try
            {
                var entity = await _dbContext.Set<T>().FirstOrDefaultAsync(criteria);
                return entity != null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
