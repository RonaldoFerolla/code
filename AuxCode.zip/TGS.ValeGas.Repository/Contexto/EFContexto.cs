﻿using Microsoft.EntityFrameworkCore;
using TGS.ValeGas.Domain.Entidades;

namespace TGS.ValeGas.Repository.Contexto
{
    public class EFContexto : DbContext
    {
        public EFContexto(DbContextOptions<EFContexto> options)
            : base(options)
        {
        }

        public virtual DbSet<AspNetRoles> AspNetRoles { get; set; }
        public virtual DbSet<AspNetUserClaims> AspNetUserClaims { get; set; }
        public virtual DbSet<AspNetUserRoles> AspNetUserRoles { get; set; }
        public virtual DbSet<AspNetUsers> AspNetUsers { get; set; }
        public virtual DbSet<Beneficiarios> Beneficiarios { get; set; }
        public virtual DbSet<Distribuidores> Distribuidores { get; set; }
        public virtual DbSet<EstadosBeneficiariosPC> EstadosBeneficiariosPC { get; set; }
        public virtual DbSet<EstadosDistribuidoresPC> EstadosDistribuidoresPC { get; set; }
        public virtual DbSet<EstadosFornecedoresSelosPC> EstadosFornecedoresSelosPC { get; set; }
        public virtual DbSet<EstadosNumeracaoSelosBeneficiariosPC> EstadosNumeracaoSelosBeneficiariosPC { get; set; }
        public virtual DbSet<EstadosNumeracaoSelosPC> EstadosNumeracaoSelosPC { get; set; }
        public virtual DbSet<FornecedoresSelos> FornecedoresSelos { get; set; }
        public virtual DbSet<LogSistema> LogSistema { get; set; }
        public virtual DbSet<NumeracaoSelos> NumeracaoSelos { get; set; }
        public virtual DbSet<NumeracaoSelosBeneficiarios> NumeracaoSelosBeneficiarios { get; set; }
        public virtual DbSet<Usuarios> Usuarios { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfigurationsFromAssembly(typeof(EFContexto).Assembly);
            base.OnModelCreating(modelBuilder);
        }
    }
}
